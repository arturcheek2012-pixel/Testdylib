#import <UIKit/UIKit.h>
@interface AGEdgeWindow : UIWindow
@end
