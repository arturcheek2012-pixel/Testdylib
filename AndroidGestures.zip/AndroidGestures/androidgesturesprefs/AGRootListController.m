#import <Preferences/PSListController.h>
#import <notify.h>
#import <spawn.h>
#import <unistd.h>

@interface AGRootListController : PSListController
@end
@implementation AGRootListController
- (NSArray *)specifiers {
    if (!_specifiers) _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    return _specifiers;
}
- (void)resetSettings {
    NSUserDefaults *d = [[NSUserDefaults alloc] initWithSuiteName:@"com.androidgestures"];
    [d removePersistentDomainForName:@"com.androidgestures"];
    [d synchronize];
    notify_post("com.androidgestures/prefsChanged");
    [self reloadSpecifiers];
}
- (void)respring {
    const char *paths[] = { "/var/jb/usr/bin/sbreload", "/usr/bin/sbreload" };
    for (int i = 0; i < 2; i++) if (access(paths[i], X_OK) == 0) {
        pid_t pid; char *argv[] = { (char *)paths[i], NULL };
        posix_spawn(&pid, paths[i], NULL, NULL, argv, NULL); return;
    }
}
@end
