#include <Arduino.h>
#include <Adafruit_GFX.h>
#include <math.h>
#include "Games.h"

namespace Games {
namespace {
int g_id = -1; uint32_t g_last = 0; float g_intro = 0;
const char* const kNames[GAME_COUNT] = {"Ping Pong", "Flappy Bird", "Maze FPS (Doom-like)"};
float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }

// ============================ PING GAME_PONG ============================
const float PAD_H = 12, PAD_W = 3;
struct { float py, ay, bx, by, vx, vy, wait; uint8_t ps, as; bool over; } pg;
void pongServe(int dir) { pg.bx = 64; pg.by = 31; pg.vx = dir * 60.0f; pg.vy = (float)random(-30, 31); pg.wait = 0.8f; }
void pongStart() { pg.ps = pg.as = 0; pg.py = pg.ay = 26; pg.over = false; pongServe(1); }
void pongUpdate(float dt, const Input& in) {
  if (pg.over) { if (in.okPress) pongStart(); return; }
  pg.py = clampf(pg.py + ((in.down ? 1 : 0) - (in.up ? 1 : 0)) * 80.0f * dt, 0, 64 - PAD_H);
  if (pg.wait > 0) { pg.wait -= dt; return; }
  float d = (pg.by - PAD_H / 2) - pg.ay, sp = 46.0f * dt;                       // AI follows with limited speed
  pg.ay = clampf(pg.ay + clampf(d, -sp, sp), 0, 64 - PAD_H);
  pg.bx += pg.vx * dt; pg.by += pg.vy * dt;
  if (pg.by < 0) { pg.by = 0; pg.vy = -pg.vy; }
  if (pg.by > 62) { pg.by = 62; pg.vy = -pg.vy; }
  if (pg.vx < 0 && pg.bx <= 7 && pg.bx >= 1 && pg.by + 2 >= pg.py && pg.by <= pg.py + PAD_H) {
    pg.bx = 7; pg.vx = clampf(-pg.vx * 1.07f, -130, 130); pg.vy = clampf(pg.vy + ((pg.by + 1) - (pg.py + PAD_H / 2)) * 6.0f, -100, 100);
  }
  if (pg.vx > 0 && pg.bx + 2 >= 121 && pg.bx <= 125 && pg.by + 2 >= pg.ay && pg.by <= pg.ay + PAD_H) {
    pg.bx = 119; pg.vx = clampf(-pg.vx * 1.07f, -130, 130); pg.vy = clampf(pg.vy + ((pg.by + 1) - (pg.ay + PAD_H / 2)) * 6.0f, -100, 100);
  }
  if (pg.bx < -4) { pg.as++; if (pg.as >= 5) pg.over = true; else pongServe(-1); }
  else if (pg.bx > 132) { pg.ps++; if (pg.ps >= 5) pg.over = true; else pongServe(1); }
}
void pongDraw(Adafruit_GFX& g) {
  for (int y = 0; y < 64; y += 6) g.drawFastVLine(63, y, 3, 1);
  g.setTextSize(1); g.setTextColor(1);
  g.setCursor(50, 0); g.print((int)pg.ps); g.setCursor(74, 0); g.print((int)pg.as);
  g.fillRect(4, (int)pg.py, (int)PAD_W, (int)PAD_H, 1);
  g.fillRect(121, (int)pg.ay, (int)PAD_W, (int)PAD_H, 1);
  g.fillRect((int)pg.bx, (int)pg.by, 2, 2, 1);
  if (pg.over) { g.fillRect(24, 22, 80, 22, 0); g.drawRect(24, 22, 80, 22, 1);
    g.setCursor(34, 26); g.print(pg.ps >= 5 ? "YOU WIN!" : "YOU LOSE"); g.setCursor(30, 36); g.print("OK = again"); }
  else if (g_intro > 0) { g.setCursor(8, 56); g.print("UP/DOWN = paddle"); }
}

// ============================ GAME_FLAPPY BIRD ============================
const int BIRD_X = 30, PIPE_GAP = 24, PIPE_W = 14, PIPE_SP = 52, NUM_PIPES = 3;
struct Pipe { float x; int gap; bool passed; } pipes[NUM_PIPES];
float fy, fvy, deadT; int fscore, fbest = 0; bool fdead, fstarted;
int randGap() { return (int)random(10, 64 - 10 - PIPE_GAP + 1); }
void flappyStart() {
  fy = 28; fvy = 0; fscore = 0; fdead = false; fstarted = false; deadT = 0;
  for (int i = 0; i < NUM_PIPES; i++) { pipes[i].x = 140 + i * PIPE_SP; pipes[i].gap = randGap(); pipes[i].passed = false; }
}
void flappyUpdate(float dt, const Input& in) {
  bool flap = in.okPress || in.upPress;
  if (fdead) { deadT += dt; if (flap && deadT > 0.6f) flappyStart(); return; }
  if (!fstarted) { if (flap) { fstarted = true; fvy = -95; } return; }
  if (flap) fvy = -95;
  fvy += 300.0f * dt; fy += fvy * dt;
  for (int i = 0; i < NUM_PIPES; i++) {
    Pipe& p = pipes[i]; p.x -= 40.0f * dt;
    if (p.x < -PIPE_W) { p.x += NUM_PIPES * PIPE_SP; p.gap = randGap(); p.passed = false; }
    if (!p.passed && p.x + PIPE_W < BIRD_X - 3) { p.passed = true; fscore++; if (fscore > fbest) fbest = fscore; }
    if (BIRD_X + 3 > p.x && BIRD_X - 3 < p.x + PIPE_W && (fy - 3 < p.gap || fy + 3 > p.gap + PIPE_GAP)) fdead = true;
  }
  if (fy < 3 || fy > 61) fdead = true;
}
void flappyDraw(Adafruit_GFX& g) {
  for (int i = 0; i < NUM_PIPES; i++) {
    int x = (int)pipes[i].x; g.fillRect(x, 0, PIPE_W, pipes[i].gap, 1); g.fillRect(x, pipes[i].gap + PIPE_GAP, PIPE_W, 64 - pipes[i].gap - PIPE_GAP, 1);
    g.fillRect(x + 2, 0, PIPE_W - 4, pipes[i].gap > 2 ? pipes[i].gap - 2 : 0, 0);
    g.fillRect(x + 2, pipes[i].gap + PIPE_GAP + 2, PIPE_W - 4, 64 - pipes[i].gap - PIPE_GAP - 2, 0);
  }
  g.fillCircle(BIRD_X, (int)fy, 3, 1); g.drawPixel(BIRD_X + 1, (int)fy - 1, 0);
  g.fillRect(52, 0, 24, 9, 0); g.setTextSize(1); g.setTextColor(1); g.setCursor(56, 1); g.print(fscore);
  if (!fstarted) { g.fillRect(14, 26, 100, 12, 0); g.setCursor(18, 29); g.print("UP / OK = flap"); }
  if (fdead) { g.fillRect(22, 20, 84, 24, 0); g.drawRect(22, 20, 84, 24, 1);
    g.setCursor(30, 24); g.print("Score "); g.print(fscore); g.print(" Best "); g.print(fbest);
    g.setCursor(30, 34); g.print("OK = retry"); }
}

// ============================ GAME_MAZE FPS (raycaster) ============================
const char* const kMap[16] = {
"################","#......#.......#","#.####.#.#####.#","#.#....#.....#.#","#.#.########.#.#","#.#........#.#.#",
"#.########.#.#.#","#..........#...#","####.#######.###","#....#.......#.#","#.####.#####.#.#","#......#...#...#",
"######.#.#.###.#","#......#.#.....#","#.######.#####E#","################"};
float mx_, my_, ma; bool mwon; float mtime;
void mazeStart() { mx_ = 1.5f; my_ = 1.5f; ma = 0.0f; mwon = false; mtime = 0; }
char cellAt(float x, float y) { int cx = (int)x, cy = (int)y; if (cx < 0 || cy < 0 || cx > 15 || cy > 15) return '#'; return kMap[cy][cx]; }
void mazeUpdate(float dt, const Input& in) {
  if (mwon) { if (in.okPress) mazeStart(); return; }
  mtime += dt;
  if (in.okHeld) { ma += ((in.down ? 1 : 0) - (in.up ? 1 : 0)) * 2.2f * dt; }
  else {
    float s = ((in.up ? 1 : 0) - (in.down ? 1 : 0)) * 2.4f * dt;
    if (s != 0) {
      float nx = mx_ + cosf(ma) * s, ny = my_ + sinf(ma) * s, m = s > 0 ? 0.2f : -0.2f;
      char cx = cellAt(nx + cosf(ma) * m, my_), cy = cellAt(mx_, ny + sinf(ma) * m);
      if (cx == 'E' || cy == 'E') { mwon = true; return; }
      if (cx == '.') mx_ = nx;
      if (cy == '.') my_ = ny;
    }
  }
  if (ma > 6.2831853f) ma -= 6.2831853f; if (ma < 0) ma += 6.2831853f;
}
void mazeDraw(Adafruit_GFX& g) {
  float dx = cosf(ma), dy = sinf(ma), plx = -dy * 0.66f, ply = dx * 0.66f;
  for (int col = 0; col < 64; col++) {
    float cam = 2.0f * col / 64.0f - 1.0f, rdx = dx + plx * cam, rdy = dy + ply * cam;
    int mx = (int)mx_, my = (int)my_;
    float ddx = rdx == 0 ? 1e30f : fabsf(1.0f / rdx), ddy = rdy == 0 ? 1e30f : fabsf(1.0f / rdy), sdx, sdy; int stx, sty;
    if (rdx < 0) { stx = -1; sdx = (mx_ - mx) * ddx; } else { stx = 1; sdx = (mx + 1.0f - mx_) * ddx; }
    if (rdy < 0) { sty = -1; sdy = (my_ - my) * ddy; } else { sty = 1; sdy = (my + 1.0f - my_) * ddy; }
    int side = 0; char hit = '#';
    for (int i = 0; i < 24; i++) {
      if (sdx < sdy) { sdx += ddx; mx += stx; side = 0; } else { sdy += ddy; my += sty; side = 1; }
      if (mx < 0 || my < 0 || mx > 15 || my > 15) { hit = '#'; break; }
      char c = kMap[my][mx]; if (c != '.') { hit = c; break; }
    }
    float perp = side == 0 ? sdx - ddx : sdy - ddy; if (perp < 0.05f) perp = 0.05f;
    int h = (int)(64.0f / perp); if (h > 64) h = 64;
    int y0 = 32 - h / 2, x = col * 2;
    bool dither = side == 1 || perp > 5.0f;
    for (int dxp = 0; dxp < 2; dxp++) {
      int xx = x + dxp;
      if (hit == 'E') { for (int y = y0; y < y0 + h; y++) if ((y & 3) != 3) g.drawPixel(xx, y, 1); }
      else if (!dither) g.drawFastVLine(xx, y0, h, 1);
      else for (int y = y0 + ((xx & 1) ? 1 : 0); y < y0 + h; y += 2) g.drawPixel(xx, y, 1);
    }
  }
  for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) { char c = kMap[y][x]; if (c == '#') g.drawPixel(x, y, 1); else if (c == 'E') { g.drawPixel(x, y, 0); } }
  g.drawPixel((int)mx_, (int)my_, (millis() / 250) & 1);
  g.setTextSize(1); g.setTextColor(1);
  if (mwon) { g.fillRect(14, 18, 100, 28, 0); g.drawRect(14, 18, 100, 28, 1);
    g.setCursor(22, 22); g.print("ESCAPED!  "); g.print((int)mtime); g.print("s"); g.setCursor(22, 34); g.print("OK = again"); }
  else if (g_intro > 0) { g.fillRect(0, 46, 128, 18, 0); g.setCursor(0, 47); g.print("UP fwd  DOWN back"); g.setCursor(0, 56); g.print("hold OK + UP/DOWN: turn"); }
}
}  // namespace

const char* name(int id) { return (id >= 0 && id < GAME_COUNT) ? kNames[id] : "?"; }
void start(int id) {
  g_id = id; g_last = 0; g_intro = 3.0f; randomSeed(micros());
  if (id == GAME_PONG) pongStart(); else if (id == GAME_FLAPPY) flappyStart(); else if (id == GAME_MAZE) mazeStart();
}
void update(uint32_t now, const Input& in) {
  float dt = g_last ? (now - g_last) / 1000.0f : 0.04f; g_last = now;
  dt = clampf(dt, 0.005f, 0.1f);
  if (g_intro > 0) g_intro -= dt;
  if (g_id == GAME_PONG) pongUpdate(dt, in); else if (g_id == GAME_FLAPPY) flappyUpdate(dt, in); else if (g_id == GAME_MAZE) mazeUpdate(dt, in);
}
void draw(Adafruit_GFX& g) {
  if (g_id == GAME_PONG) pongDraw(g); else if (g_id == GAME_FLAPPY) flappyDraw(g); else if (g_id == GAME_MAZE) mazeDraw(g);
}
}
