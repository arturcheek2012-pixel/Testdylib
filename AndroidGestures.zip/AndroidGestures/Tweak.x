#import <UIKit/UIKit.h>
#import "AGSettings.h"
#import "AGEdgeWindow.h"
#import "AGBackAction.h"

static AGEdgeWindow *gWindow;

%group SpringBoardGroup
%hook SpringBoard
- (void)applicationDidFinishLaunching:(id)application {
    %orig;
    dispatch_async(dispatch_get_main_queue(), ^{
        [AGSettings shared];
        gWindow = [[AGEdgeWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    });
}
%end
%end

%ctor {
    if ([[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.apple.springboard"]) {
        %init(SpringBoardGroup);
    } else {
        AGStartBackListener(); // app-side: performs the real "back"
    }
}
