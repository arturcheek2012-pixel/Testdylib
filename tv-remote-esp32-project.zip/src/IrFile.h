// Pure C++ streaming parser for Flipper ".ir" files (no Arduino dependency).
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "IrCodec.h"

struct IByteSource {
  virtual ~IByteSource() {}
  virtual int  read(uint8_t* buf, size_t n) = 0;   // bytes read, <=0 on EOF/error
  virtual bool seek(uint32_t off) = 0;
  virtual uint32_t size() = 0;
};

static const size_t kNameLen = 24;
struct IrSignal {
  char     name[kNameLen];
  Proto    proto;        // Proto::Raw for raw signals
  bool     isRaw;
  uint32_t address;      // up to 4 bytes, little endian (as in the file)
  uint32_t command;
  uint32_t freq;         // raw only
  uint8_t  dutyPct;      // raw only
  uint16_t rawCount;     // raw only; timings live in the buffer given to IrParser
  uint32_t offset;       // file offset of the "name:" line
};

bool irCheckHeader(IByteSource& s);   // "Filetype: IR signals file" / "IR library file"

class IrParser {
 public:
  IrParser(IByteSource& s, uint32_t* rawBuf, size_t rawCap);
  bool begin(uint32_t off);          // seek and reset
  bool next(IrSignal& out);          // next valid signal; false on EOF
 private:
  enum Line { L_EOF, L_COMMENT, L_BLANK, L_FIELD };
  int  gc();
  Line readLine(char* key, size_t kc, char* val, size_t vc, uint32_t& lineStart);
  bool readOne(IrSignal& s, bool& valid);
  IByteSource& src_; uint32_t* raw_; size_t rawCap_;
  uint8_t buf_[256]; int bufLen_, bufPos_; uint32_t pos_;
  size_t rawN_; bool rawOver_;
  bool pend_; char pendName_[kNameLen]; uint32_t pendOff_;
};
