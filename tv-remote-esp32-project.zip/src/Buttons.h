#pragma once
#include <Arduino.h>
enum class Btn : uint8_t { None, Up, Down, Ok, Back, OkLong };
// Debounced buttons. Up/Down/Back fire on press (Up/Down auto-repeat),
// Ok fires on release (so a long press can be told apart), OkLong after 800 ms hold.
void buttonsBegin();
Btn  buttonsPoll();
