#import "AGBackView.h"
#import "AGSettings.h"

@implementation AGBackView {
    CAShapeLayer *_shape, *_arrow;
    BOOL _right; CGFloat _lastY, _lastP; NSUInteger _gen;
}
- (instancetype)initWithFrame:(CGRect)f right:(BOOL)right {
    if (!(self = [super initWithFrame:f])) return nil;
    _right = right; self.userInteractionEnabled = NO; self.hidden = YES;
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _shape = [CAShapeLayer layer]; _shape.fillColor = [UIColor blackColor].CGColor;
    [self.layer addSublayer:_shape];
    _arrow = [CAShapeLayer layer];
    _arrow.strokeColor = [UIColor whiteColor].CGColor; _arrow.fillColor = nil;
    _arrow.lineWidth = 2.6; _arrow.lineCap = kCALineCapRound; _arrow.lineJoin = kCALineJoinRound;
    UIBezierPath *a = [UIBezierPath bezierPath]; // left-pointing arrow centred on origin
    [a moveToPoint:CGPointMake(8, 0)]; [a addLineToPoint:CGPointMake(-8, 0)];
    [a moveToPoint:CGPointMake(-1.5, -6.5)]; [a addLineToPoint:CGPointMake(-8, 0)]; [a addLineToPoint:CGPointMake(-1.5, 6.5)];
    _arrow.path = a.CGPath; _arrow.opacity = 0;
    [self.layer addSublayer:_arrow];
    return self;
}
- (void)layoutSubviews { [super layoutSubviews]; _shape.frame = self.bounds; }

static void AGDims(NSInteger style, CGFloat *w, CGFloat *h) {
    switch (style) { case 1: *w = 34; *h = 60; break; case 2: *w = 56; *h = 110; break; default: *w = 44; *h = 85; }
}
- (UIBezierPath *)pathForProgress:(CGFloat)p y:(CGFloat)y {
    CGFloat mw, hh; AGDims([AGSettings shared].animStyle, &mw, &hh);
    CGFloat w = p * mw, h = hh * (0.55 + 0.45 * MIN(p, 1)), W = self.bounds.size.width;
    CGFloat (^X)(CGFloat) = ^CGFloat(CGFloat x) { return self->_right ? W - x : x; };
    UIBezierPath *b = [UIBezierPath bezierPath];
    [b moveToPoint:CGPointMake(X(0), y - h)];
    [b addCurveToPoint:CGPointMake(X(w), y) controlPoint1:CGPointMake(X(0), y - h * 0.5) controlPoint2:CGPointMake(X(w), y - h * 0.5)];
    [b addCurveToPoint:CGPointMake(X(0), y + h) controlPoint1:CGPointMake(X(w), y + h * 0.5) controlPoint2:CGPointMake(X(0), y + h * 0.5)];
    [b closePath];
    return b;
}
- (CGFloat)clampY:(CGFloat)y {
    CGFloat mw, hh; AGDims([AGSettings shared].animStyle, &mw, &hh);
    return MIN(MAX(y, hh + 20), self.bounds.size.height - hh - 20);
}
- (CGFloat)arrowScale:(CGFloat)p { return 0.6 + 0.4 * MIN(p, 1); }

- (void)setProgress:(CGFloat)p y:(CGFloat)y {
    _gen++; [_shape removeAllAnimations]; [_arrow removeAllAnimations];
    self.hidden = NO; y = [self clampY:y]; _lastY = y; _lastP = p;
    CGFloat mw, hh; AGDims([AGSettings shared].animStyle, &mw, &hh);
    [CATransaction begin]; [CATransaction setDisableActions:YES];
    _shape.path = [self pathForProgress:p y:y].CGPath;
    _arrow.hidden = ![AGSettings shared].arrowVisible;
    _arrow.opacity = MIN(1, MAX(0, (p - 0.2) / 0.5));
    _arrow.position = CGPointMake(_right ? self.bounds.size.width - p * mw * 0.5 : p * mw * 0.5, y);
    CGFloat s = [self arrowScale:p];
    _arrow.transform = CATransform3DMakeScale(_right ? -s : s, s, 1);
    [CATransaction commit];
}
- (void)retractAfter:(CFTimeInterval)delay duration:(CFTimeInterval)d {
    NSUInteger gen = _gen;
    CGPathRef from = ((CAShapeLayer *)_shape.presentationLayer).path ?: _shape.path;
    UIBezierPath *to = [self pathForProgress:0 y:_lastY];
    float op = ((CAShapeLayer *)_arrow.presentationLayer).opacity;
    [CATransaction begin];
    [CATransaction setCompletionBlock:^{ if (gen == self->_gen) self.hidden = YES; }];
    _shape.path = to.CGPath; _arrow.opacity = 0;
    CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"path"];
    a.fromValue = (__bridge id)from; a.toValue = (__bridge id)to.CGPath;
    a.duration = d; a.beginTime = CACurrentMediaTime() + delay; a.fillMode = kCAFillModeBackwards;
    a.timingFunction = [CAMediaTimingFunction functionWithControlPoints:0.3 :0 :0.8 :0.15];
    [_shape addAnimation:a forKey:@"retract"];
    CABasicAnimation *f = [CABasicAnimation animationWithKeyPath:@"opacity"];
    f.fromValue = @(op); f.toValue = @0; f.duration = d * 0.7; f.beginTime = a.beginTime; f.fillMode = kCAFillModeBackwards;
    [_arrow addAnimation:f forKey:@"fade"];
    [CATransaction commit];
}
- (void)animateSuccess {
    CGFloat sp = [AGSettings shared].animSpeed;
    CGFloat s = [self arrowScale:_lastP];
    CABasicAnimation *pulse = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    pulse.fromValue = @(s); pulse.toValue = @(s * 1.3); pulse.duration = 0.09 / sp; pulse.autoreverses = YES;
    [_arrow addAnimation:pulse forKey:@"pulse"];
    [self retractAfter:0.1 / sp duration:0.26 / sp];
}
- (void)animateCancel {
    CGFloat sp = [AGSettings shared].animSpeed;
    [self retractAfter:0 duration:([AGSettings shared].cancelMode == 1 ? 0.1 : 0.3) / sp];
}
@end
