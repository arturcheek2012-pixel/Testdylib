#import "AGEdgeWindow.h"
#import "AGBackView.h"
#import "AGHaptics.h"
#import "AGSettings.h"
#import "AGBackAction.h"

@interface SBApplication : NSObject
- (NSString *)bundleIdentifier;
@end
@interface SpringBoard : UIApplication
- (SBApplication *)_accessibilityFrontMostApplication;
@end

static BOOL AGFrontAppAllowed(void) {
    NSString *bid = [[(SpringBoard *)UIApplication.sharedApplication _accessibilityFrontMostApplication] bundleIdentifier];
    return bid && ![[AGSettings shared] isExcluded:bid];
}

@interface AGTouchView : UIView @end
@implementation AGTouchView {
    AGBackView *_lv, *_rv;
    BOOL _tracking, _began, _armed, _isRight; CGPoint _start;
}
- (instancetype)initWithFrame:(CGRect)f {
    if (!(self = [super initWithFrame:f])) return nil;
    self.backgroundColor = UIColor.clearColor;
    _lv = [[AGBackView alloc] initWithFrame:self.bounds right:NO];
    _rv = [[AGBackView alloc] initWithFrame:self.bounds right:YES];
    [self addSubview:_lv]; [self addSubview:_rv];
    return self;
}
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)e {
    AGSettings *s = [AGSettings shared];
    if (!s.enabled) return nil;
    if (_tracking) return self;
    CGFloat W = self.bounds.size.width;
    BOOL inL = s.left && p.x <= s.edgeWidth, inR = s.right && p.x >= W - s.edgeWidth;
    if (!(inL || inR)) return nil;
    return AGFrontAppAllowed() ? self : nil;
}
- (void)touchesBegan:(NSSet<UITouch *> *)t withEvent:(UIEvent *)e {
    if (_tracking) return;
    CGPoint p = [t.anyObject locationInView:self];
    _tracking = YES; _began = NO; _armed = NO; _start = p; _isRight = p.x > self.bounds.size.width / 2;
}
- (void)touchesMoved:(NSSet<UITouch *> *)t withEvent:(UIEvent *)e {
    if (!_tracking) return;
    AGSettings *s = [AGSettings shared];
    CGPoint p = [t.anyObject locationInView:self];
    CGFloat dx = _isRight ? _start.x - p.x : p.x - _start.x, dy = p.y - _start.y;
    if (!_began) {
        if (fabs(dx) + fabs(dy) < 8) return;
        if (dx <= 0 || fabs(dy) > fabs(dx)) { _tracking = NO; return; } // vertical / wrong direction: ignore silently
        _began = YES; [AGHaptics begin];
    }
    CGFloat prog = MIN(1, MAX(0, dx * s.sensitivity / s.activationDistance));
    [(_isRight ? _rv : _lv) setProgress:prog y:p.y];
    if (!_armed && prog >= s.threshold) { _armed = YES; [AGHaptics threshold]; }
    else if (_armed && prog < s.threshold - 0.08) _armed = NO;
}
- (void)finish:(BOOL)commit {
    AGBackView *v = _isRight ? _rv : _lv;
    if (_began) {
        if (commit) { [AGHaptics success]; [v animateSuccess]; AGPostBack(); }
        else { [AGHaptics cancel]; [v animateCancel]; }
    }
    _tracking = NO; _began = NO; _armed = NO;
}
- (void)touchesEnded:(NSSet<UITouch *> *)t withEvent:(UIEvent *)e { [self finish:_armed]; }
- (void)touchesCancelled:(NSSet<UITouch *> *)t withEvent:(UIEvent *)e { [self finish:NO]; }
@end

@implementation AGEdgeWindow
- (instancetype)initWithFrame:(CGRect)f {
    if (!(self = [super initWithFrame:f])) return nil;
    self.windowLevel = UIWindowLevelAlert + 1000;
    self.backgroundColor = UIColor.clearColor;
    UIViewController *vc = [UIViewController new];
    vc.view = [[AGTouchView alloc] initWithFrame:f];
    self.rootViewController = vc;
    self.hidden = NO;
    return self;
}
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)e {
    UIView *root = self.rootViewController.view;
    return [root hitTest:[self convertPoint:p toView:root] withEvent:e]; // nil => touch falls through
}
@end
