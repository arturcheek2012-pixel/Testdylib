#pragma once
#include <stdint.h>
class Adafruit_GFX;
namespace Games {
enum Id { GAME_PONG = 0, GAME_FLAPPY = 1, GAME_MAZE = 2, GAME_COUNT = 3 };
struct Input { bool up, down, okHeld, okPress, upPress; };
const char* name(int id);
void start(int id);
void update(uint32_t nowMs, const Input& in);   // call ~25 times per second
void draw(Adafruit_GFX& g);                      // screen must be cleared by the caller
}
