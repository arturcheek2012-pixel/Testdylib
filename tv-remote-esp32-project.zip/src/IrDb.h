#pragma once
#include <Arduino.h>
#include "config.h"
namespace IrDb {
struct Stats {
  bool cardFound, initOk, tvDirOk, uniOk, truncated, ready;
  uint16_t brands, profiles, withPower, uniqueScan, files, skippedFiles, readErrors;
  uint32_t signals, sendable, unsupported;
  uint64_t cardBytes;
};
typedef void (*Progress)(uint16_t done, uint16_t total);

bool mount();                    // SD init (never formats)
void build(Progress cb);         // (re)index; safe to call again
const Stats& stats();

uint16_t brandCount();
const char* brandName(uint16_t b);
uint16_t brandFirst(uint16_t b);
uint16_t brandSize(uint16_t b);

const char* profileName(uint16_t p);
const char* profileBrand(uint16_t p);
const char* profilePath(uint16_t p);
uint32_t profileStart(uint16_t p);
bool profileScannable(uint16_t p);       // has a sendable Power and is not a duplicate
const char* profilePowerProto(uint16_t p);
int findProfile(const char* path, uint32_t start);

uint16_t loadCommands(uint16_t p);       // fills the command table of profile p
const char* cmdLabel(uint16_t i);
bool sendCmd(uint16_t p, uint16_t cmdIdx);
bool sendPower(uint16_t p);
bool powerInfo(uint16_t p, char* out, size_t n);   // e.g. "NEC a=04 c=08" / "raw 38k 67"
}
