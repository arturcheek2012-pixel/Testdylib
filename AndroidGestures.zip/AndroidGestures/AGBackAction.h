#import <Foundation/Foundation.h>
#ifdef __cplusplus
extern "C" {
#endif
void AGPostBack(void);          // called in SpringBoard
void AGStartBackListener(void); // called in every app process
#ifdef __cplusplus
}
#endif
