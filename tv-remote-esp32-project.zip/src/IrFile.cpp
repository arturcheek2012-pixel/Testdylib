#include "IrFile.h"
#include <string.h>
#include <stdlib.h>

bool irCheckHeader(IByteSource& s) {
  uint8_t b[64]; if (!s.seek(0)) return false;
  int n = s.read(b, sizeof b - 1); if (n < 12) return false; b[n] = 0;
  const char* p = (const char*)b;
  if ((uint8_t)p[0] == 0xEF && (uint8_t)p[1] == 0xBB && (uint8_t)p[2] == 0xBF) p += 3;
  return strncmp(p, "Filetype: IR signals file", 25) == 0 || strncmp(p, "Filetype: IR library file", 25) == 0;
}

IrParser::IrParser(IByteSource& s, uint32_t* rawBuf, size_t rawCap)
  : src_(s), raw_(rawBuf), rawCap_(rawCap), bufLen_(0), bufPos_(0), pos_(0),
    rawN_(0), rawOver_(false), pend_(false), pendOff_(0) { pendName_[0] = 0; }

bool IrParser::begin(uint32_t off) {
  bufLen_ = bufPos_ = 0; pos_ = off; pend_ = false; rawN_ = 0; rawOver_ = false;
  return src_.seek(off);
}
int IrParser::gc() {
  if (bufPos_ >= bufLen_) {
    bufLen_ = src_.read(buf_, sizeof buf_); bufPos_ = 0;
    if (bufLen_ <= 0) { bufLen_ = 0; return -1; }
  }
  pos_++; return buf_[bufPos_++];
}

IrParser::Line IrParser::readLine(char* key, size_t kc, char* val, size_t vc, uint32_t& ls) {
  ls = pos_; int c = gc();
  if (c < 0) return LN_EOF;
  if (c == '\n' || c == '\r') return LN_BLANK;
  if (c == '#') { while ((c = gc()) >= 0 && c != '\n') {} return LN_COMMENT; }
  size_t k = 0;
  while (c >= 0 && c != ':' && c != '\n') { if (k + 1 < kc) key[k++] = (char)c; c = gc(); }
  while (k && (key[k - 1] == ' ' || key[k - 1] == '\r')) k--;
  key[k] = 0; val[0] = 0;
  if (c != ':') return LN_BLANK;
  if (strcmp(key, "data") == 0) {
    rawN_ = 0; rawOver_ = false; uint32_t acc = 0; bool in = false;
    while ((c = gc()) >= 0 && c != '\n') {
      if (c >= '0' && c <= '9') { if (acc < 100000000u) acc = acc * 10 + (uint32_t)(c - '0'); in = true; }
      else if (in) { if (rawN_ < rawCap_) raw_[rawN_++] = acc; else rawOver_ = true; acc = 0; in = false; }
    }
    if (in) { if (rawN_ < rawCap_) raw_[rawN_++] = acc; else rawOver_ = true; }
    return LN_FIELD;
  }
  size_t v = 0;
  while ((c = gc()) >= 0 && c != '\n') {
    if (c == '\r') continue;
    if (v == 0 && c == ' ') continue;
    if (v + 1 < vc) val[v++] = (char)c;
  }
  while (v && val[v - 1] == ' ') v--;
  val[v] = 0; return LN_FIELD;
}

static void copyName(char* d, const char* s) {
  size_t i = 0;
  for (; s[i] && i + 1 < kNameLen; i++) { unsigned char ch = (unsigned char)s[i]; d[i] = (ch >= 32 && ch < 127) ? (char)ch : '?'; }
  d[i] = 0;
}
static uint32_t parseBytes(const char* s) {
  uint32_t v = 0; int i = 0;
  while (*s && i < 4) {
    while (*s == ' ') s++;
    if (!*s) break;
    char* e; unsigned long b = strtoul(s, &e, 16); if (e == s) break;
    v |= (uint32_t)(b & 0xFF) << (8 * i++); s = e;
  }
  return v;
}

bool IrParser::readOne(IrSignal& s, bool& valid) {
  memset(&s, 0, sizeof s); s.dutyPct = 33; rawN_ = 0; rawOver_ = false;
  bool have = false, sType = false, sProto = false, sAddr = false, sCmd = false, isRaw = false;
  if (pend_) { have = true; strncpy(s.name, pendName_, kNameLen - 1); s.offset = pendOff_; pend_ = false; }
  char key[16], val[64]; uint32_t ls;
  for (;;) {
    Line k = readLine(key, sizeof key, val, sizeof val, ls);
    if (k == LN_EOF) { if (!have) return false; break; }
    if (k != LN_FIELD) continue;
    if (strcmp(key, "name") == 0) {
      if (have) { pend_ = true; copyName(pendName_, val); pendOff_ = ls; break; }
      have = true; copyName(s.name, val); s.offset = ls; continue;
    }
    if (!have) continue;
    if (strcmp(key, "type") == 0) { sType = true; isRaw = (strcmp(val, "raw") == 0); if (!isRaw && strcmp(val, "parsed") != 0) sType = false; }
    else if (strcmp(key, "protocol") == 0) { sProto = true; protoFromName(val, s.proto); }
    else if (strcmp(key, "address") == 0) { sAddr = true; s.address = parseBytes(val); }
    else if (strcmp(key, "command") == 0) { sCmd = true; s.command = parseBytes(val); }
    else if (strcmp(key, "frequency") == 0) { s.freq = (uint32_t)strtoul(val, nullptr, 10); }
    else if (strcmp(key, "duty_cycle") == 0) { double d = strtod(val, nullptr); if (d >= 0.05 && d <= 0.95) s.dutyPct = (uint8_t)(d * 100.0 + 0.5); }
  }
  s.isRaw = isRaw;
  if (isRaw) {
    valid = sType && rawN_ >= 2 && !rawOver_;
    s.proto = Proto::Raw; s.rawCount = (uint16_t)rawN_;
    if (s.freq < 10000 || s.freq > 100000) s.freq = 38000;
  } else {
    valid = sType && sProto && sAddr && sCmd;
  }
  return true;
}

bool IrParser::next(IrSignal& out) {
  bool valid;
  while (readOne(out, valid)) if (valid) return true;
  return false;
}
