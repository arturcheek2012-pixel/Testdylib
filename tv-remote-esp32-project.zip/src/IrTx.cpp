#include <Arduino.h>
#include <IRsend.h>
#include "IrTx.h"
#include "config.h"

namespace {
IRsend irsend(IR_TX_PIN, IR_TX_INVERTED ? true : false, true);
uint32_t g_out[kMaxRaw + 8 > 1400 ? kMaxRaw + 8 : 1400];
bool g_toggle = false;
}

namespace IrTx {
void begin() { irsend.begin(); }

bool send(const IrSignal& s, const uint32_t* raw) {
  uint32_t carrier = 38000; uint8_t duty = 33; size_t n;
  if (s.isRaw) {
    n = irEncodeRaw(raw, s.rawCount, g_out, sizeof g_out / sizeof g_out[0]);
    carrier = s.freq; duty = s.dutyPct;
  } else {
    n = irEncode(s.proto, s.address, s.command, g_toggle, g_out, sizeof g_out / sizeof g_out[0], carrier, duty);
    if (n && (s.proto == Proto::RC5 || s.proto == Proto::RC5X || s.proto == Proto::RC6)) g_toggle = !g_toggle;
  }
  if (!n) return false;
  if (duty < 10) duty = 10;
  if (duty > 90) duty = 90;
  irsend.enableIROut(carrier, duty);
  for (size_t i = 0; i < n; i++) {
    if ((i & 1) == 0) irsend.mark(g_out[i] > 65535 ? 65535 : (uint16_t)g_out[i]);
    else irsend.space(g_out[i]);
  }
  irsend.space(0);
  return true;
}
}
