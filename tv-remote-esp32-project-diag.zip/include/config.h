#pragma once
#include <stdint.h>

#define FW_VERSION "1.0.2-diag"

// ---- Given by the user ----------------------------------------------------
#define PIN_BTN_UP   27
#define PIN_BTN_DOWN 26
#define PIN_BTN_OK   33
#define PIN_BTN_BACK 32

// ---- ASSUMPTIONS (not confirmed, override with -D in platformio.ini) -------
// IR-TX -> G16 per the ESP-HACK connection scheme (matches the earlier "D16" reading).
// (On WROVER modules GPIO16/17 are used by PSRAM and cannot be used.)
#ifndef IR_TX_PIN
#define IR_TX_PIN 16
#endif
// 1 if the transistor stage inverts the logic level (LED lit when pin is LOW).
#ifndef IR_TX_INVERTED
#define IR_TX_INVERTED 0
#endif
// Buttons: 1 = pressed reads LOW (internal pull-up). 0 = pressed reads HIGH.
#ifndef BTN_ACTIVE_LOW
#define BTN_ACTIVE_LOW 1
#endif
// OLED I2C. Pins/address were NOT specified. 0 = auto-probe 0x3C then 0x3D.
#ifndef PIN_OLED_SDA
#define PIN_OLED_SDA 21
#endif
#ifndef PIN_OLED_SCL
#define PIN_OLED_SCL 22
#endif
#ifndef OLED_I2C_ADDR
#define OLED_I2C_ADDR 0
#endif
#ifndef OLED_ROT
#define OLED_ROT 0   // 0 or 2 (180 deg) if the module is mounted upside down
#endif
// SD over SPI. Pins from the ESP-HACK connection scheme (github.com/Teapot174/ESP-HACK README):
// SD: CS->G15, MOSI->G13, CLK->G14, MISO->G17, power 3V3.
#ifndef PIN_SD_CS
#define PIN_SD_CS 15
#endif
#ifndef PIN_SD_SCK
#define PIN_SD_SCK 14
#endif
#ifndef PIN_SD_MISO
#define PIN_SD_MISO 17
#endif
#ifndef PIN_SD_MOSI
#define PIN_SD_MOSI 13
#endif

// ---- Database layout (taken from sdcard_3.zip; "sdcard 2/" = card root) ----
#define DB_TV_DIR   "/infrared/assets/TVs"
#define DB_UNI_FILE "/infrared/assets/tv.ir"

// ---- Limits (RAM is static; overflow is reported, never silent) ------------
static const uint16_t kMaxProfiles = 768;
static const uint16_t kMaxBrands   = 96;
static const uint16_t kMaxFiles    = 160;
static const uint16_t kMaxCmds     = 96;
static const uint16_t kMaxRaw      = 1024;   // raw timings per signal
static const uint16_t kPoolSize    = 14336;  // names + paths
static const uint8_t  kMaxFavs     = 16;
