#pragma once
#include <Arduino.h>
#include "config.h"
namespace Store {
struct Settings { uint8_t bri; uint8_t tmo; uint8_t spd; };  // indices into option tables
struct Fav { char path[80]; uint32_t start; char title[24]; };
extern Settings set;
void begin();                  // load settings + favorites (defaults on any error)
bool saveSettings();
uint8_t favCount();
const Fav& fav(uint8_t i);
int  favFind(const char* path, uint32_t start);
enum FavResult { FAV_OK, FAV_EXISTS, FAV_FULL, FAV_WRITE_FAIL, FAV_BAD };
FavResult favAdd(const char* path, uint32_t start, const char* title);
bool favRemove(uint8_t i);
}
