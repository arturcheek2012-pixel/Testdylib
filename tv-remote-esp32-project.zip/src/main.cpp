#include <Arduino.h>
#include "Ui.h"
void setup() { Serial.begin(115200); uiBegin(); }
void loop()  { uiTick(); delay(1); }
