#include <Preferences.h>
#include <string.h>
#include "Store.h"

namespace Store {
Settings set = {3, 0, 1};
namespace {
struct Blob { uint8_t ver; uint8_t n; uint8_t pad[2]; Fav f[kMaxFavs]; };
Blob g_blob;
const char* kNs = "tvr";
bool saveBlob() {
  Preferences p; if (!p.begin(kNs, false)) return false;
  size_t w = p.putBytes("fav", &g_blob, sizeof g_blob);
  if (w != sizeof g_blob) w = p.putBytes("fav", &g_blob, sizeof g_blob);   // one retry
  p.end(); return w == sizeof g_blob;
}
}

void begin() {
  memset(&g_blob, 0, sizeof g_blob); g_blob.ver = 1;
  Preferences p; if (!p.begin(kNs, false)) return;
  uint8_t b = p.getUChar("bri", 3), t = p.getUChar("tmo", 0), s = p.getUChar("spd", 1);
  set.bri = b < 5 ? b : 3; set.tmo = t < 5 ? t : 0; set.spd = s < 4 ? s : 1;
  if (p.getBytesLength("fav") == sizeof g_blob) {
    Blob tmp; p.getBytes("fav", &tmp, sizeof tmp);
    if (tmp.ver == 1 && tmp.n <= kMaxFavs) {
      for (int i = 0; i < tmp.n; i++) { tmp.f[i].path[sizeof tmp.f[i].path - 1] = 0; tmp.f[i].title[sizeof tmp.f[i].title - 1] = 0; }
      g_blob = tmp;
    }
  }
  p.end();
}
bool saveSettings() {
  Preferences p; if (!p.begin(kNs, false)) return false;
  p.putUChar("bri", set.bri); p.putUChar("tmo", set.tmo); p.putUChar("spd", set.spd);
  p.end(); return true;
}
uint8_t favCount() { return g_blob.n; }
const Fav& fav(uint8_t i) { return g_blob.f[i < kMaxFavs ? i : 0]; }
int favFind(const char* path, uint32_t start) {
  for (int i = 0; i < g_blob.n; i++) if (g_blob.f[i].start == start && strcmp(g_blob.f[i].path, path) == 0) return i;
  return -1;
}
FavResult favAdd(const char* path, uint32_t start, const char* title) {
  if (!path || strlen(path) >= sizeof g_blob.f[0].path) return FAV_BAD;
  if (favFind(path, start) >= 0) return FAV_EXISTS;
  if (g_blob.n >= kMaxFavs) return FAV_FULL;
  Blob old = g_blob; Fav& f = g_blob.f[g_blob.n];
  memset(&f, 0, sizeof f); strncpy(f.path, path, sizeof f.path - 1); f.start = start; strncpy(f.title, title, sizeof f.title - 1);
  g_blob.n++;
  if (!saveBlob()) { g_blob = old; return FAV_WRITE_FAIL; }
  return FAV_OK;
}
bool favRemove(uint8_t i) {
  if (i >= g_blob.n) return false;
  Blob old = g_blob;
  for (int k = i; k + 1 < g_blob.n; k++) g_blob.f[k] = g_blob.f[k + 1];
  g_blob.n--; memset(&g_blob.f[g_blob.n], 0, sizeof(Fav));
  if (!saveBlob()) { g_blob = old; return false; }
  return true;
}
}
