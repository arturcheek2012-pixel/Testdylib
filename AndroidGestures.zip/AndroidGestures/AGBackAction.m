#import <UIKit/UIKit.h>
#import <objc/message.h>
#import <notify.h>
#import "AGBackAction.h"

void AGPostBack(void) { notify_post("com.androidgestures/back"); }

static UIWindow *AGKeyWindow(void) {
    UIApplication *app = UIApplication.sharedApplication;
    for (UIScene *s in app.connectedScenes)
        if ([s isKindOfClass:UIWindowScene.class] && s.activationState == UISceneActivationStateForegroundActive)
            for (UIWindow *w in ((UIWindowScene *)s).windows) if (w.isKeyWindow) return w;
    return app.keyWindow;
}
static UIViewController *AGLeaf(UIViewController *vc) {
    if (vc.presentedViewController) return AGLeaf(vc.presentedViewController);
    if ([vc isKindOfClass:UINavigationController.class] && ((UINavigationController *)vc).topViewController)
        return AGLeaf(((UINavigationController *)vc).topViewController);
    if ([vc isKindOfClass:UITabBarController.class] && ((UITabBarController *)vc).selectedViewController)
        return AGLeaf(((UITabBarController *)vc).selectedViewController);
    return vc;
}
static UIView *AGFindWeb(UIView *v) {
    Class c = NSClassFromString(@"WKWebView");
    if (c && [v isKindOfClass:c] && !v.hidden && v.window) return v;
    for (UIView *s in v.subviews.reverseObjectEnumerator) { UIView *r = AGFindWeb(s); if (r) return r; }
    return nil;
}
static BOOL AGBackInApp(void) {
    UIWindow *w = AGKeyWindow(); if (!w) return NO;
    UIViewController *leaf = AGLeaf(w.rootViewController);
    for (UIViewController *v = leaf; v; v = v.parentViewController) {          // 1) pop navigation stack
        if ([v isKindOfClass:UINavigationController.class] && ((UINavigationController *)v).viewControllers.count > 1) {
            [(UINavigationController *)v popViewControllerAnimated:YES]; return YES;
        }
    }
    UIView *web = AGFindWeb(w);                                                // 2) web history (Safari etc.)
    if (web && [[web valueForKey:@"canGoBack"] boolValue]) {
        ((void (*)(id, SEL))objc_msgSend)(web, NSSelectorFromString(@"goBack")); return YES;
    }
    for (UIViewController *v = leaf; v; v = v.parentViewController) {          // 3) dismiss modal
        if (v.presentingViewController.presentedViewController == v) { [v dismissViewControllerAnimated:YES completion:nil]; return YES; }
    }
    return NO;
}
static void AGBackNotify(CFNotificationCenterRef c, void *o, CFStringRef n, const void *obj, CFDictionaryRef u) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIApplication *app = UIApplication.sharedApplication;
        if (app && app.applicationState == UIApplicationStateActive) AGBackInApp();
    });
}
void AGStartBackListener(void) {
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, AGBackNotify,
        CFSTR("com.androidgestures/back"), NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
}
