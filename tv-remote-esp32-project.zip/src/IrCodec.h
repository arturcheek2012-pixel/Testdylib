// Pure C++ (no Arduino): Flipper .ir protocol -> mark/space timing list.
#pragma once
#include <stdint.h>
#include <stddef.h>

enum class Proto : uint8_t {
  Unknown, Raw, NEC, NECext, NEC42, NEC42ext, Samsung32, SIRC, SIRC15, SIRC20,
  RC5, RC5X, RC6, RCA, Kaseikyo, Pioneer
};
bool        protoFromName(const char* n, Proto& out);
const char* protoName(Proto p);
bool        protoSendable(Proto p);   // true only if an encoder exists

enum Role : uint8_t {
  ROLE_POWER, ROLE_VOLUP, ROLE_VOLDN, ROLE_CHUP, ROLE_CHDN, ROLE_MUTE, ROLE_MENU, ROLE_OK, ROLE_BACK,
  ROLE_UP, ROLE_DOWN, ROLE_LEFT, ROLE_RIGHT, ROLE_SOURCE, ROLE_COUNT, ROLE_NONE = 255
};
uint8_t     roleFromName(const char* name);
const char* roleLabel(uint8_t r);

// Output: t[0]=mark, t[1]=space, ... (microseconds). Returns count, 0 on failure.
size_t irEncode(Proto p, uint32_t addr, uint32_t cmd, bool toggle,
                uint32_t* out, size_t cap, uint32_t& carrierHz, uint8_t& dutyPct);
size_t irEncodeRaw(const uint32_t* in, size_t n, uint32_t* out, size_t cap);
