#import <UIKit/UIKit.h>
@interface AGBackView : UIView
- (instancetype)initWithFrame:(CGRect)f right:(BOOL)right;
- (void)setProgress:(CGFloat)p y:(CGFloat)y;
- (void)animateSuccess;
- (void)animateCancel;
@end
