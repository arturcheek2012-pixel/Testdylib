#import <UIKit/UIKit.h>
#import "AGSettings.h"
#import "AGEdgeWindow.h"
#import "AGBackAction.h"

%group SpringBoardGroup
%hook SpringBoard
- (void)applicationDidFinishLaunching:(id)application {
    %orig;
    dispatch_async(dispatch_get_main_queue(), ^{ AGEdgeWindowsStart(); });
}
%end
%end

%ctor {
    if ([[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.apple.springboard"]) {
        %init(SpringBoardGroup);
        // Safety nets: start the edge windows even if the hook above was missed.
        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidFinishLaunchingNotification object:nil
            queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) { AGEdgeWindowsStart(); }];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 10 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            if (UIApplication.sharedApplication) AGEdgeWindowsStart();
        });
    } else {
        AGStartBackListener(); // app-side: performs the real "back"
    }
}
