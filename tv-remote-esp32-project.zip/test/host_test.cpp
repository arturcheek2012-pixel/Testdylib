// Host-side check of IrFile + IrCodec against the real database.
// g++ -std=c++11 -I src test/host_test.cpp src/IrFile.cpp src/IrCodec.cpp -o /tmp/host_test
#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <dirent.h>
#include <sys/stat.h>
#include "IrFile.h"
struct FSrc : IByteSource {
  FILE* f; uint32_t sz; FSrc(FILE* x) : f(x) { fseek(f, 0, SEEK_END); sz = ftell(f); fseek(f, 0, SEEK_SET); }
  int read(uint8_t* b, size_t n) override { size_t r = fread(b, 1, n, f); return (int)r; }
  bool seek(uint32_t o) override { return fseek(f, o, SEEK_SET) == 0; }
  uint32_t size() override { return sz; }
};
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static uint32_t decodeBits(const uint32_t* t, size_t n, uint32_t hdr, size_t bits) {  // pulse-distance, MSB = first bit
  uint32_t v = 0; size_t k = 2; (void)hdr;
  for (size_t i = 0; i < bits; i++, k += 2) v = (v << 1) | (t[k + 1] > 1000 ? 1 : 0);
  return v;
}
static std::map<std::string, int> g_proto, g_unsup; static int g_files = 0, g_sig = 0, g_enc = 0, g_encfail = 0, g_bad = 0;
static uint32_t RAW[1024], OUT[1400];
static void scan(const std::string& path) {
  FILE* f = fopen(path.c_str(), "rb"); if (!f) return; FSrc s(f);
  if (!irCheckHeader(s)) { printf("no header: %s\n", path.c_str()); fclose(f); g_bad++; return; }
  g_files++; IrParser p(s, RAW, 1024); p.begin(0); IrSignal sg;
  while (p.next(sg)) {
    g_sig++; g_proto[protoName(sg.proto)]++;
    uint32_t car; uint8_t duty; size_t n;
    if (sg.isRaw) n = irEncodeRaw(RAW, sg.rawCount, OUT, 1400);
    else if (protoSendable(sg.proto)) n = irEncode(sg.proto, sg.address, sg.command, false, OUT, 1400, car, duty);
    else { g_unsup[protoName(sg.proto)]++; continue; }
    if (n) g_enc++; else { g_encfail++; printf("encode fail %s %s %s\n", path.c_str(), sg.name, protoName(sg.proto)); }
  }
}
static void walk(const std::string& d) {
  DIR* dp = opendir(d.c_str()); if (!dp) return; dirent* e;
  while ((e = readdir(dp))) {
    if (e->d_name[0] == '.') continue; std::string p = d + "/" + e->d_name; struct stat st; stat(p.c_str(), &st);
    if (S_ISDIR(st.st_mode)) walk(p); else scan(p);
  }
  closedir(dp);
}
int main(int argc, char** argv) {
  uint32_t car; uint8_t duty; size_t n;
  n = irEncode(Proto::NEC, 0x04, 0x08, false, OUT, 1400, car, duty);          // LG TV power
  CHECK(n == 67 && decodeBits(OUT, n, 0, 32) == 0x20DF10EF && OUT[0] == 9000 && OUT[1] == 4500 && car == 38000);
  n = irEncode(Proto::Samsung32, 0x07, 0x02, false, OUT, 1400, car, duty);    // Samsung TV power
  CHECK(n == 67 && decodeBits(OUT, n, 0, 32) == 0xE0E040BF);
  n = irEncode(Proto::NECext, 0xBF00, 0xF20D, false, OUT, 1400, car, duty);   // bytes 00 BF 0D F2 -> rev8 = 00 FD B0 4F
  CHECK(n == 67 && decodeBits(OUT, n, 0, 32) == 0x00FDB04F);
  n = irEncode(Proto::SIRC, 0x01, 0x15, false, OUT, 1400, car, duty);         // Sony power, 3 frames
  CHECK(n > 0 && car == 40000 && OUT[0] == 2400);
  uint32_t tot = 0; for (size_t i = 0; i < n; i++) tot += OUT[i]; CHECK(tot > 2 * 45000 && tot < 3 * 45000);
  n = irEncode(Proto::RC5, 0x00, 0x0C, false, OUT, 1400, car, duty); CHECK(n > 0 && car == 36000);
  n = irEncode(Proto::RC6, 0x00, 0x0C, false, OUT, 1400, car, duty); CHECK(n > 0 && OUT[0] == 2666);
  n = irEncode(Proto::RCA, 0x0F, 0x01, false, OUT, 1400, car, duty); CHECK(n == 51 && car == 56000);
  CHECK(roleFromName("Powa") == ROLE_POWER && roleFromName("VOL+") == ROLE_VOLUP && roleFromName("Ch_next") == ROLE_CHUP && roleFromName("Enter") == ROLE_NONE);
  CHECK(!protoSendable(Proto::Kaseikyo) && protoSendable(Proto::Raw));
  if (argc > 1) { walk(std::string(argv[1]) + "/TVs"); scan(std::string(argv[1]) + "/tv.ir"); }
  printf("files=%d signals=%d encoded_ok=%d encode_fail=%d badheader=%d\n", g_files, g_sig, g_enc, g_encfail, g_bad);
  for (auto& kv : g_proto) printf("  %-10s %d\n", kv.first.c_str(), kv.second);
  for (auto& kv : g_unsup) printf("  unsupported %-10s %d\n", kv.first.c_str(), kv.second);
  printf(fails ? "UNIT TESTS FAILED\n" : "unit vectors OK\n"); return fails || g_encfail;
}
