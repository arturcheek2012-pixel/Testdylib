#include "IrCodec.h"
#include <string.h>
#include <ctype.h>

struct PInfo { const char* name; Proto p; bool send; };
static const PInfo kP[] = {
  {"NEC", Proto::NEC, true},       {"NECext", Proto::NECext, true},
  {"NEC42", Proto::NEC42, false},  {"NEC42ext", Proto::NEC42ext, false},
  {"Samsung32", Proto::Samsung32, true},
  {"SIRC", Proto::SIRC, true},     {"SIRC15", Proto::SIRC15, true}, {"SIRC20", Proto::SIRC20, true},
  {"RC5", Proto::RC5, true},       {"RC5X", Proto::RC5X, true},     {"RC6", Proto::RC6, true},
  {"RCA", Proto::RCA, true},
  {"Kaseikyo", Proto::Kaseikyo, false}, {"Pioneer", Proto::Pioneer, false},
};
bool protoFromName(const char* n, Proto& o) {
  for (size_t i = 0; i < sizeof(kP) / sizeof(kP[0]); i++)
    if (strcmp(n, kP[i].name) == 0) { o = kP[i].p; return true; }
  o = Proto::Unknown; return false;
}
const char* protoName(Proto p) {
  if (p == Proto::Raw) return "raw";
  for (size_t i = 0; i < sizeof(kP) / sizeof(kP[0]); i++) if (kP[i].p == p) return kP[i].name;
  return "?";
}
bool protoSendable(Proto p) {
  if (p == Proto::Raw) return true;
  for (size_t i = 0; i < sizeof(kP) / sizeof(kP[0]); i++) if (kP[i].p == p) return kP[i].send;
  return false;
}

struct RN { const char* n; uint8_t r; };
static const RN kRoles[] = {
  {"power",ROLE_POWER},{"powa",ROLE_POWER},{"tvpower",ROLE_POWER},{"onoff",ROLE_POWER},{"escaladetvpower",ROLE_POWER},
  {"volup",ROLE_VOLUP},{"vol+",ROLE_VOLUP},{"voldn",ROLE_VOLDN},{"voldown",ROLE_VOLDN},{"vol-",ROLE_VOLDN},
  {"chnext",ROLE_CHUP},{"chup",ROLE_CHUP},{"chanelup",ROLE_CHUP},{"ch+",ROLE_CHUP},
  {"chprev",ROLE_CHDN},{"chdown",ROLE_CHDN},{"chaneldown",ROLE_CHDN},{"ch-",ROLE_CHDN},
  {"mute",ROLE_MUTE},{"menu",ROLE_MENU},{"navmenu",ROLE_MENU},{"menue",ROLE_MENU},
  {"ok",ROLE_OK},{"navok",ROLE_OK},{"center",ROLE_OK},
  {"back",ROLE_BACK},{"return",ROLE_BACK},{"navback",ROLE_BACK},
  {"up",ROLE_UP},{"arrowup",ROLE_UP},{"navup",ROLE_UP},
  {"down",ROLE_DOWN},{"arrowdown",ROLE_DOWN},{"navdn",ROLE_DOWN},
  {"left",ROLE_LEFT},{"arrowleft",ROLE_LEFT},{"navlft",ROLE_LEFT},
  {"right",ROLE_RIGHT},{"arrowright",ROLE_RIGHT},{"navrgt",ROLE_RIGHT},
  {"source",ROLE_SOURCE},{"input",ROLE_SOURCE},{"sources",ROLE_SOURCE},
};
uint8_t roleFromName(const char* name) {
  char b[24]; size_t k = 0;
  for (const char* p = name; *p && k + 1 < sizeof b; p++) {
    if (*p == '_' || *p == ' ') continue;
    b[k++] = (char)tolower((unsigned char)*p);
  }
  b[k] = 0;
  for (size_t i = 0; i < sizeof(kRoles) / sizeof(kRoles[0]); i++)
    if (strcmp(b, kRoles[i].n) == 0) return kRoles[i].r;
  return ROLE_NONE;
}
const char* roleLabel(uint8_t r) {
  static const char* L[ROLE_COUNT] = {"Power","Vol +","Vol -","Ch +","Ch -","Mute","Menu","OK","Back","Up","Down","Left","Right","Source"};
  return r < ROLE_COUNT ? L[r] : "";
}

struct Wave { uint32_t* t; size_t cap; size_t n; bool over; };
static void lvl(Wave& w, bool mark, uint32_t us) {
  if (!us) return;
  if (w.n == 0) { if (!mark) return; }
  else if ((((w.n - 1) % 2) == 0) == mark) { w.t[w.n - 1] += us; return; }
  if (w.n < w.cap) w.t[w.n++] = us; else w.over = true;
}
static void pulseDist(Wave& w, uint32_t hm, uint32_t hs, const uint8_t* b, int nb,
                      uint32_t bm, uint32_t s0, uint32_t s1) {
  lvl(w, true, hm); lvl(w, false, hs);
  for (int i = 0; i < nb; i++)
    for (int k = 0; k < 8; k++) { lvl(w, true, bm); lvl(w, false, ((b[i] >> k) & 1) ? s1 : s0); }
  lvl(w, true, bm);
}
static void manch(Wave& w, bool bit, uint32_t half, bool oneIsMarkFirst) {
  bool markFirst = (bit == oneIsMarkFirst);
  lvl(w, markFirst, half); lvl(w, !markFirst, half);
}

size_t irEncode(Proto p, uint32_t a, uint32_t c, bool tog, uint32_t* out, size_t cap,
                uint32_t& carrier, uint8_t& duty) {
  Wave w = {out, cap, 0, false}; duty = 33; carrier = 38000;
  switch (p) {
    case Proto::NEC: {
      uint8_t A = a & 0xFF, C = c & 0xFF; uint8_t b[4] = {A, (uint8_t)~A, C, (uint8_t)~C};
      pulseDist(w, 9000, 4500, b, 4, 560, 560, 1690); break; }
    case Proto::NECext: {
      uint8_t b[4] = {(uint8_t)(a & 0xFF), (uint8_t)((a >> 8) & 0xFF), (uint8_t)(c & 0xFF), (uint8_t)((c >> 8) & 0xFF)};
      pulseDist(w, 9000, 4500, b, 4, 560, 560, 1690); break; }
    case Proto::Samsung32: {
      uint8_t a0 = a & 0xFF, a1 = (a >> 8) & 0xFF; if (a1 == 0) a1 = a0;
      uint8_t C = c & 0xFF; uint8_t b[4] = {a0, a1, C, (uint8_t)~C};
      pulseDist(w, 4500, 4500, b, 4, 550, 550, 1650); break; }
    case Proto::SIRC: case Proto::SIRC15: case Proto::SIRC20: {
      int ab = (p == Proto::SIRC) ? 5 : (p == Proto::SIRC15 ? 8 : 13);
      uint32_t data = (c & 0x7F) | ((a & ((1u << ab) - 1)) << 7); int nb = 7 + ab;
      carrier = 40000;
      for (int rep = 0; rep < 3; rep++) {
        uint32_t tot = 3000;
        lvl(w, true, 2400); lvl(w, false, 600);
        for (int i = 0; i < nb; i++) {
          uint32_t m = ((data >> i) & 1) ? 1200 : 600; lvl(w, true, m); lvl(w, false, 600); tot += m + 600;
        }
        if (rep < 2 && tot < 45000) lvl(w, false, 45000 - tot);
      }
      break; }
    case Proto::RC5: case Proto::RC5X: {
      carrier = 36000; bool bits[14];
      bits[0] = true; bits[1] = !((c >> 6) & 1); bits[2] = tog;
      for (int i = 0; i < 5; i++) bits[3 + i] = (a >> (4 - i)) & 1;
      for (int i = 0; i < 6; i++) bits[8 + i] = (c >> (5 - i)) & 1;
      for (int i = 0; i < 14; i++) manch(w, bits[i], 889, false);
      break; }
    case Proto::RC6: {
      carrier = 36000;
      lvl(w, true, 2666); lvl(w, false, 889);
      manch(w, true, 444, true);
      for (int i = 0; i < 3; i++) manch(w, false, 444, true);
      manch(w, tog, 889, true);
      for (int i = 0; i < 8; i++) manch(w, (a >> (7 - i)) & 1, 444, true);
      for (int i = 0; i < 8; i++) manch(w, (c >> (7 - i)) & 1, 444, true);
      break; }
    case Proto::RCA: {
      carrier = 56000; uint32_t A = a & 0xF, C = c & 0xFF;
      uint32_t v = (A << 20) | (C << 12) | ((~A & 0xF) << 8) | (~C & 0xFF);
      lvl(w, true, 4000); lvl(w, false, 4000);
      for (int i = 23; i >= 0; i--) { lvl(w, true, 500); lvl(w, false, ((v >> i) & 1) ? 2000 : 1000); }
      lvl(w, true, 500);
      break; }
    default: return 0;
  }
  return w.over ? 0 : w.n;
}

size_t irEncodeRaw(const uint32_t* in, size_t n, uint32_t* out, size_t cap) {
  if (n < 2 || n > cap) return 0;
  uint64_t tot = 0;
  for (size_t i = 0; i < n; i++) { if (in[i] == 0) return 0; out[i] = in[i]; tot += in[i]; }
  if (tot > 2000000ULL) return 0;
  return n;
}
