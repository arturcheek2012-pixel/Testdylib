#import <UIKit/UIKit.h>
#import "AGHaptics.h"
#import "AGSettings.h"
@implementation AGHaptics
+ (void)fire:(UIImpactFeedbackStyle)style {
    UIImpactFeedbackGenerator *g = [[UIImpactFeedbackGenerator alloc] initWithStyle:style];
    [g prepare];
    [g impactOccurredWithIntensity:MIN(1, MAX(0.1, [AGSettings shared].hapticIntensity))];
}
+ (void)begin { if ([AGSettings shared].haptics) [self fire:UIImpactFeedbackStyleLight]; }
+ (void)threshold { if ([AGSettings shared].haptics) [self fire:UIImpactFeedbackStyleMedium]; }
+ (void)success { AGSettings *s = [AGSettings shared]; if (s.haptics && s.hapticOnSuccess) [self fire:UIImpactFeedbackStyleRigid]; }
+ (void)cancel { if ([AGSettings shared].haptics) [self fire:UIImpactFeedbackStyleSoft]; }
@end
