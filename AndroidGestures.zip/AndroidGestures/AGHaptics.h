#import <Foundation/Foundation.h>
@interface AGHaptics : NSObject
+ (void)begin; + (void)threshold; + (void)success; + (void)cancel;
@end
