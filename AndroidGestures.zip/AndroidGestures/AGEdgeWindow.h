#import <UIKit/UIKit.h>

// One thin window per screen edge (only the edge strip belongs to SpringBoard,
// everything else keeps reaching the app). The strip grows while a gesture is
// in progress so the bubble has room to be drawn.
@interface AGEdgeWindow : UIWindow
@property (nonatomic, readonly) BOOL isRightEdge;
@property (nonatomic) BOOL busy;
- (instancetype)initWithRightEdge:(BOOL)right;
- (void)refreshStrip;
- (void)expandForBubble;
- (void)collapseAfter:(NSTimeInterval)delay;
@end

#ifdef __cplusplus
extern "C" {
#endif
void AGEdgeWindowsStart(void); // idempotent, main thread, SpringBoard only
#ifdef __cplusplus
}
#endif
