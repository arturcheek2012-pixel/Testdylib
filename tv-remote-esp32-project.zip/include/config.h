#pragma once
#include <stdint.h>

#define FW_VERSION "1.0.0"

// ---- Given by the user ----------------------------------------------------
#define PIN_BTN_UP   27
#define PIN_BTN_DOWN 26
#define PIN_BTN_OK   33
#define PIN_BTN_BACK 32

// ---- ASSUMPTIONS (not confirmed, override with -D in platformio.ini) -------
// "D16" is read as GPIO16. Verify against your board silkscreen/schematic.
// (On WROVER modules GPIO16/17 are used by PSRAM and cannot be used.)
#ifndef IR_TX_PIN
#define IR_TX_PIN 16
#endif
// 1 if the transistor stage inverts the logic level (LED lit when pin is LOW).
#ifndef IR_TX_INVERTED
#define IR_TX_INVERTED 0
#endif
// Buttons: 1 = pressed reads LOW (internal pull-up). 0 = pressed reads HIGH.
#ifndef BTN_ACTIVE_LOW
#define BTN_ACTIVE_LOW 1
#endif
// OLED I2C. Pins/address were NOT specified. 0 = auto-probe 0x3C then 0x3D.
#ifndef OLED_SDA
#define OLED_SDA 21
#endif
#ifndef OLED_SCL
#define OLED_SCL 22
#endif
#ifndef OLED_ADDR
#define OLED_ADDR 0
#endif
#ifndef OLED_ROTATION
#define OLED_ROTATION 0   // 0 or 2 (180 deg) if the module is mounted upside down
#endif
// SD over SPI. Pins were NOT specified (these are the ESP32 VSPI defaults).
#ifndef SD_CS
#define SD_CS 5
#endif
#ifndef SD_SCK
#define SD_SCK 18
#endif
#ifndef SD_MISO
#define SD_MISO 19
#endif
#ifndef SD_MOSI
#define SD_MOSI 23
#endif

// ---- Database layout (taken from sdcard_3.zip; "sdcard 2/" = card root) ----
#define DB_TV_DIR   "/infrared/assets/TVs"
#define DB_UNI_FILE "/infrared/assets/tv.ir"

// ---- Limits (RAM is static; overflow is reported, never silent) ------------
static const uint16_t kMaxProfiles = 768;
static const uint16_t kMaxBrands   = 96;
static const uint16_t kMaxFiles    = 160;
static const uint16_t kMaxCmds     = 96;
static const uint16_t kMaxRaw      = 1024;   // raw timings per signal
static const uint16_t kPoolSize    = 14336;  // names + paths
static const uint8_t  kMaxFavs     = 16;
