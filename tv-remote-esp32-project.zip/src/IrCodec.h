// Pure C++ (no Arduino): Flipper .ir protocol -> mark/space timing list.
#pragma once
#include <stdint.h>
#include <stddef.h>

enum class Proto : uint8_t {
  Unknown, Raw, NEC, NECext, NEC42, NEC42ext, Samsung32, SIRC, SIRC15, SIRC20,
  RC5, RC5X, RC6, RCA, Kaseikyo, Pioneer
};
bool        protoFromName(const char* n, Proto& out);
const char* protoName(Proto p);
bool        protoSendable(Proto p);   // true only if an encoder exists

enum Role : uint8_t {
  R_POWER, R_VOLUP, R_VOLDN, R_CHUP, R_CHDN, R_MUTE, R_MENU, R_OK, R_BACK,
  R_UP, R_DOWN, R_LEFT, R_RIGHT, R_SOURCE, R_COUNT, R_NONE = 255
};
uint8_t     roleFromName(const char* name);
const char* roleLabel(uint8_t r);

// Output: t[0]=mark, t[1]=space, ... (microseconds). Returns count, 0 on failure.
size_t irEncode(Proto p, uint32_t addr, uint32_t cmd, bool toggle,
                uint32_t* out, size_t cap, uint32_t& carrierHz, uint8_t& dutyPct);
size_t irEncodeRaw(const uint32_t* in, size_t n, uint32_t* out, size_t cap);
