#include <SD.h>
#include <SPI.h>
#include <string.h>
#include <stdlib.h>
#include <strings.h>
#include <algorithm>
#include "IrDb.h"
#include "IrFile.h"
#include "IrTx.h"

namespace IrDb {
namespace {
const uint32_t kNoOff = 0xFFFFFFFFu;
const uint16_t kNoStr = 0xFFFF;
enum { FLG_DUP = 1, FLG_UNI = 2 };

struct Profile {
  uint32_t start, end, powerOff, powerHash;
  uint16_t brandOff, nameOff, file, sendable;
  uint8_t powerProto, flags;
};
struct Brand { uint16_t nameOff, first, count; };
struct Cmd { char label[20]; uint32_t off; uint8_t rank; };

char g_pool[kPoolSize]; uint16_t g_poolUsed;
uint16_t g_filePath[kMaxFiles]; uint16_t g_nFiles;
Profile g_prof[kMaxProfiles]; uint16_t g_nProf;
Brand g_brand[kMaxBrands]; uint16_t g_nBrand;
Cmd g_cmd[kMaxCmds]; uint16_t g_nCmd;
uint32_t g_raw[kMaxRaw];
uint32_t g_seen[2048];
Stats g_st;

class SdSource : public IByteSource {
 public:
  explicit SdSource(File& f) : f_(f), fail_(false) {}
  int read(uint8_t* b, size_t n) override { int r = (int)f_.read(b, n); if (r < 0) fail_ = true; return r; }
  bool seek(uint32_t o) override { return f_.seek(o); }
  uint32_t size() override { return (uint32_t)f_.size(); }
  bool failed() const { return fail_; }
 private:
  File& f_; bool fail_;
};

uint16_t addStr(const char* s) {
  size_t n = strlen(s) + 1;
  if (g_poolUsed + n > kPoolSize) { g_st.truncated = true; return kNoStr; }
  uint16_t o = g_poolUsed; memcpy(g_pool + o, s, n); g_poolUsed += (uint16_t)n; return o;
}
const char* str(uint16_t o) { return o == kNoStr ? "?" : g_pool + o; }

uint32_t fnv(uint32_t h, uint32_t v) { for (int i = 0; i < 4; i++) { h ^= (v >> (8 * i)) & 0xFF; h *= 16777619u; } return h; }
uint32_t signalHash(const IrSignal& s) {
  uint32_t h = 2166136261u;
  if (s.isRaw) { h = fnv(h, s.freq); h = fnv(h, s.rawCount); for (uint16_t i = 0; i < s.rawCount; i++) h = fnv(h, g_raw[i]); }
  else { h = fnv(h, (uint32_t)s.proto); h = fnv(h, s.address); h = fnv(h, s.command); }
  return h ? h : 1;
}
bool sendableSig(const IrSignal& s) { return s.isRaw ? s.rawCount >= 2 : protoSendable(s.proto); }

const char* baseName(const char* p) { const char* s = strrchr(p, '/'); return s ? s + 1 : p; }

bool openFile(const char* path, File& f) { f = SD.open(path, FILE_READ); return f && !f.isDirectory(); }

void addProfile(const Profile& p) {
  if (g_nProf >= kMaxProfiles) { g_st.truncated = true; return; }
  g_prof[g_nProf++] = p;
}

// One file = one profile (brand folders)
void scanBrandFile(const char* path, uint16_t brandOff, const char* fname, const char* brand) {
  File f; if (!openFile(path, f)) { g_st.readErrors++; return; }
  SdSource src(f);
  if (!irCheckHeader(src)) { g_st.skippedFiles++; f.close(); return; }
  if (g_nFiles >= kMaxFiles) { g_st.truncated = true; f.close(); return; }
  IrParser ps(src, g_raw, kMaxRaw); ps.begin(0);
  Profile pr; memset(&pr, 0, sizeof pr); pr.powerOff = kNoOff; pr.start = 0; pr.end = src.size(); pr.brandOff = brandOff;
  IrSignal s; uint32_t total = 0, snd = 0, uns = 0;
  while (ps.next(s)) {
    total++;
    if (!sendableSig(s)) { uns++; continue; }
    snd++;
    if (pr.powerOff == kNoOff && roleFromName(s.name) == ROLE_POWER) {
      pr.powerOff = s.offset; pr.powerHash = signalHash(s); pr.powerProto = (uint8_t)s.proto;
    }
  }
  if (src.failed()) g_st.readErrors++;
  f.close();
  if (snd == 0) { g_st.skippedFiles++; return; }
  // display name: file name without extension and without "<Brand>_" prefix
  char nm[40]; strncpy(nm, fname, sizeof nm - 1); nm[sizeof nm - 1] = 0;
  size_t L = strlen(nm); if (L > 3 && strcasecmp(nm + L - 3, ".ir") == 0) nm[L - 3] = 0;
  size_t bl = strlen(brand);
  if (strncasecmp(nm, brand, bl) == 0 && nm[bl] == '_' && nm[bl + 1]) memmove(nm, nm + bl + 1, strlen(nm + bl + 1) + 1);
  nm[23] = 0;
  g_filePath[g_nFiles] = addStr(path); pr.file = g_nFiles++; pr.nameOff = addStr(nm);
  pr.sendable = (uint16_t)snd; g_st.signals += total; g_st.sendable += snd; g_st.unsupported += uns;
  addProfile(pr);
}

// tv.ir: anonymous signals; a "profile" is the run that starts at a Power signal (heuristic)
void scanUniversal() {
  File f; if (!openFile(DB_UNI_FILE, f)) return;
  SdSource src(f);
  if (!irCheckHeader(src)) { f.close(); return; }
  g_st.uniOk = true;
  if (g_nFiles >= kMaxFiles) { f.close(); return; }
  uint16_t fileIdx = g_nFiles; g_filePath[g_nFiles++] = addStr(DB_UNI_FILE);
  uint16_t brandOff = addStr("Universal");
  IrParser ps(src, g_raw, kMaxRaw); ps.begin(0);
  IrSignal s; bool open = false; Profile cur; memset(&cur, 0, sizeof cur);
  uint32_t runTotal = 0, runUns = 0; uint16_t ordinal = 0; char nm[24];
  for (;;) {
    bool got = ps.next(s);
    bool isPow = got && roleFromName(s.name) == ROLE_POWER;
    if ((!got || isPow) && open) {                                  // close previous run
      cur.end = got ? s.offset : src.size();
      if (cur.sendable > 0 && cur.powerProto != (uint8_t)Proto::Unknown) {
        g_st.signals += runTotal; g_st.sendable += cur.sendable; g_st.unsupported += runUns; addProfile(cur);
      } else { g_st.signals += runTotal; g_st.unsupported += runUns + cur.sendable; }
      open = false;
    }
    if (!got) break;
    if (isPow) {
      memset(&cur, 0, sizeof cur); ordinal++; runTotal = 0; runUns = 0; open = true;
      cur.start = s.offset; cur.powerOff = kNoOff; cur.file = fileIdx; cur.brandOff = brandOff; cur.flags = FLG_UNI;
      if (sendableSig(s)) {
        cur.powerOff = s.offset; cur.powerHash = signalHash(s); cur.powerProto = (uint8_t)s.proto;
        snprintf(nm, sizeof nm, "Uni %03u %s", ordinal, protoName(s.proto));
      } else {
        cur.powerProto = (uint8_t)Proto::Unknown; snprintf(nm, sizeof nm, "Uni %03u unsupp", ordinal);
      }
      cur.nameOff = addStr(nm);
    }
    if (!open) continue;                                            // signals before the first Power: ignored
    runTotal++;
    if (sendableSig(s)) cur.sendable++; else runUns++;
  }
  if (src.failed()) g_st.readErrors++;
  f.close();
}

int cmpProf(const Profile& a, const Profile& b) {
  bool ua = a.flags & FLG_UNI, ub = b.flags & FLG_UNI;
  if (ua != ub) return ua ? 1 : -1;
  int c = strcasecmp(str(a.brandOff), str(b.brandOff));
  if (c) return c;
  c = strcasecmp(str(a.nameOff), str(b.nameOff));
  if (c) return c;
  return a.start < b.start ? -1 : (a.start > b.start ? 1 : 0);
}
bool lessProf(const Profile& a, const Profile& b) { return cmpProf(a, b) < 0; }

void finishIndex() {
  std::sort(g_prof, g_prof + g_nProf, lessProf);
  g_nBrand = 0; memset(g_seen, 0, sizeof g_seen);
  for (uint16_t i = 0; i < g_nProf; i++) {
    Profile& p = g_prof[i];
    if (g_nBrand == 0 || g_brand[g_nBrand - 1].nameOff != p.brandOff) {
      if (g_nBrand >= kMaxBrands) { g_st.truncated = true; break; }
      g_brand[g_nBrand].nameOff = p.brandOff; g_brand[g_nBrand].first = i; g_brand[g_nBrand].count = 0; g_nBrand++;
    }
    g_brand[g_nBrand - 1].count++;
    if (p.powerOff != kNoOff) {
      g_st.withPower++;
      uint32_t h = p.powerHash; uint32_t k = h & 2047; bool dup = false;
      for (int probe = 0; probe < 2048; probe++, k = (k + 1) & 2047) {
        if (g_seen[k] == 0) { g_seen[k] = h; break; }
        if (g_seen[k] == h) { dup = true; break; }
      }
      if (dup) p.flags |= FLG_DUP; else g_st.uniqueScan++;
    }
  }
  g_st.brands = g_nBrand; g_st.profiles = g_nProf; g_st.files = g_nFiles;
}
}  // namespace

bool mount() {
  memset(&g_st, 0, sizeof g_st);
  SPI.begin(PIN_SD_SCK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
  bool ok = SD.begin(PIN_SD_CS, SPI, 20000000, "/sd", 8, false);   // false = never format
  if (!ok) { SD.end(); ok = SD.begin(PIN_SD_CS, SPI, 4000000, "/sd", 8, false); }
  g_st.cardFound = ok && SD.cardType() != CARD_NONE;
  g_st.initOk = g_st.cardFound;
  if (g_st.initOk) g_st.cardBytes = SD.cardSize();
  return g_st.initOk;
}

void build(Progress cb) {
  Stats keep = g_st;
  memset(&g_st, 0, sizeof g_st);
  g_st.cardFound = keep.cardFound; g_st.initOk = keep.initOk; g_st.cardBytes = keep.cardBytes;
  g_poolUsed = 0; g_nFiles = g_nProf = g_nBrand = g_nCmd = 0;
  if (!g_st.initOk) { g_st.ready = false; return; }
  addStr("");  // offset 0 = empty string
  // collect brand folders first
  static char names[kMaxBrands][32]; uint16_t nb = 0;
  File root = SD.open(DB_TV_DIR);
  if (root && root.isDirectory()) {
    g_st.tvDirOk = true;
    for (File e = root.openNextFile(); e; e = root.openNextFile()) {
      const char* bn = baseName(e.name());
      if (e.isDirectory() && bn[0] != '.' && nb < kMaxBrands) { strncpy(names[nb], bn, 31); names[nb][31] = 0; nb++; }
      else if (e.isDirectory() && nb >= kMaxBrands) g_st.truncated = true;
      e.close();
    }
    root.close();
  }
  for (uint16_t i = 0; i < nb; i++) {
    if (cb) cb(i, nb + 1);
    char dpath[96]; snprintf(dpath, sizeof dpath, "%s/%s", DB_TV_DIR, names[i]);
    File d = SD.open(dpath);
    if (!d || !d.isDirectory()) { g_st.readErrors++; continue; }
    uint16_t brandOff = addStr(names[i]);
    for (File e = d.openNextFile(); e; e = d.openNextFile()) {
      char fn[48]; strncpy(fn, baseName(e.name()), sizeof fn - 1); fn[sizeof fn - 1] = 0;
      bool isDir = e.isDirectory(); e.close();
      if (isDir || fn[0] == '.') continue;
      char fpath[160]; snprintf(fpath, sizeof fpath, "%s/%s", dpath, fn);
      scanBrandFile(fpath, brandOff, fn, names[i]);
      yield();
    }
    d.close();
  }
  if (cb) cb(nb, nb + 1);
  scanUniversal();
  finishIndex();
  if (cb) cb(nb + 1, nb + 1);
  g_st.ready = g_st.tvDirOk || g_st.uniOk;
}

const Stats& stats() { return g_st; }
uint16_t brandCount() { return g_nBrand; }
const char* brandName(uint16_t b) { return b < g_nBrand ? str(g_brand[b].nameOff) : "?"; }
uint16_t brandFirst(uint16_t b) { return b < g_nBrand ? g_brand[b].first : 0; }
uint16_t brandSize(uint16_t b) { return b < g_nBrand ? g_brand[b].count : 0; }
const char* profileName(uint16_t p) { return p < g_nProf ? str(g_prof[p].nameOff) : "?"; }
const char* profileBrand(uint16_t p) { return p < g_nProf ? str(g_prof[p].brandOff) : "?"; }
const char* profilePath(uint16_t p) { return p < g_nProf ? str(g_filePath[g_prof[p].file]) : ""; }
uint32_t profileStart(uint16_t p) { return p < g_nProf ? g_prof[p].start : 0; }
bool profileScannable(uint16_t p) { return p < g_nProf && g_prof[p].powerOff != kNoOff && !(g_prof[p].flags & FLG_DUP); }
const char* profilePowerProto(uint16_t p) { return p < g_nProf ? protoName((Proto)g_prof[p].powerProto) : "?"; }
int findProfile(const char* path, uint32_t start) {
  for (uint16_t i = 0; i < g_nProf; i++)
    if (g_prof[i].start == start && strcmp(profilePath(i), path) == 0) return i;
  return -1;
}

uint16_t loadCommands(uint16_t p) {
  g_nCmd = 0; if (p >= g_nProf) return 0;
  const Profile& pr = g_prof[p];
  File f; if (!openFile(profilePath(p), f)) return 0;
  SdSource src(f); IrParser ps(src, g_raw, kMaxRaw);
  if (!ps.begin(pr.start)) { f.close(); return 0; }
  bool roleUsed[ROLE_COUNT]; memset(roleUsed, 0, sizeof roleUsed);
  IrSignal s;
  while (ps.next(s) && s.offset < pr.end) {
    if (!sendableSig(s)) continue;
    if (g_nCmd >= kMaxCmds) break;
    Cmd& c = g_cmd[g_nCmd]; uint8_t r = roleFromName(s.name);
    if (r != ROLE_NONE && !roleUsed[r]) { roleUsed[r] = true; c.rank = r; strncpy(c.label, roleLabel(r), sizeof c.label - 1); }
    else { c.rank = 100; strncpy(c.label, s.name, sizeof c.label - 1); }
    c.label[sizeof c.label - 1] = 0; c.off = s.offset; g_nCmd++;
  }
  f.close();
  std::stable_sort(g_cmd, g_cmd + g_nCmd, [](const Cmd& a, const Cmd& b) { return a.rank < b.rank; });
  return g_nCmd;
}
const char* cmdLabel(uint16_t i) { return i < g_nCmd ? g_cmd[i].label : ""; }

static bool sendAt(uint16_t p, uint32_t off) {
  if (p >= g_nProf) return false;
  File f; if (!openFile(profilePath(p), f)) return false;
  SdSource src(f); IrParser ps(src, g_raw, kMaxRaw);
  IrSignal s; bool ok = ps.begin(off) && ps.next(s) && s.offset == off && sendableSig(s);
  f.close();
  return ok && IrTx::send(s, g_raw);
}
bool sendCmd(uint16_t p, uint16_t i) { return i < g_nCmd && sendAt(p, g_cmd[i].off); }
bool sendPower(uint16_t p) { return p < g_nProf && g_prof[p].powerOff != kNoOff && sendAt(p, g_prof[p].powerOff); }

bool powerInfo(uint16_t p, char* out, size_t n) {
  out[0] = 0; if (p >= g_nProf || g_prof[p].powerOff == kNoOff) return false;
  File f; if (!openFile(profilePath(p), f)) return false;
  SdSource src(f); IrParser ps(src, g_raw, kMaxRaw); IrSignal s;
  bool ok = ps.begin(g_prof[p].powerOff) && ps.next(s) && s.offset == g_prof[p].powerOff;
  f.close(); if (!ok) return false;
  if (s.isRaw) snprintf(out, n, "raw %luk %u", (unsigned long)(s.freq / 1000), (unsigned)s.rawCount);
  else snprintf(out, n, "%s a=%lX c=%lX", protoName(s.proto), (unsigned long)s.address, (unsigned long)s.command);
  return true;
}
}
