#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>

// Own list of installed apps with a switch per app (replaces AltList dependency).
// Switch state is stored as "ex-<bundleID>" in com.androidgestures.
@interface AGExcludedAppsController : PSListController
@end

@implementation AGExcludedAppsController

- (NSArray *)specifiers {
    if (_specifiers) return _specifiers;

    NSMutableArray *items = [NSMutableArray array];
    NSMutableSet *seen = [NSMutableSet set];
    @try {
        Class wsClass = NSClassFromString(@"LSApplicationWorkspace");
        id ws = [wsClass performSelector:NSSelectorFromString(@"defaultWorkspace")];
        NSArray *all = [ws performSelector:NSSelectorFromString(@"allInstalledApplications")];
        for (id proxy in all) {
            NSString *bid = [proxy valueForKey:@"applicationIdentifier"];
            NSString *name = [proxy valueForKey:@"localizedName"];
            NSArray *tags = [proxy valueForKey:@"appTags"];
            if (![bid isKindOfClass:NSString.class] || ![name isKindOfClass:NSString.class] || !name.length) continue;
            if ([tags isKindOfClass:NSArray.class] && [tags containsObject:@"hidden"]) continue;
            if ([seen containsObject:bid]) continue;
            [seen addObject:bid];
            [items addObject:@{ @"bid": bid, @"name": name }];
        }
    } @catch (NSException *e) {}

    [items sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        return [a[@"name"] caseInsensitiveCompare:b[@"name"]];
    }];

    NSMutableArray *specs = [NSMutableArray array];
    [specs addObject:[PSSpecifier groupSpecifierWithName:@"Gesture is disabled in selected apps"]];
    for (NSDictionary *it in items) {
        PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:it[@"name"]
                                                        target:self
                                                           set:@selector(setPreferenceValue:specifier:)
                                                           get:@selector(readPreferenceValue:)
                                                        detail:nil
                                                          cell:PSSwitchCell
                                                          edit:nil];
        [s setProperty:@"com.androidgestures" forKey:@"defaults"];
        [s setProperty:[@"ex-" stringByAppendingString:it[@"bid"]] forKey:@"key"];
        [s setProperty:@NO forKey:@"default"];
        [s setProperty:@"com.androidgestures/prefsChanged" forKey:@"PostNotification"];
        [specs addObject:s];
    }
    _specifiers = specs;
    return _specifiers;
}

@end
