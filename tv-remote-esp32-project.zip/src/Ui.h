#pragma once
void uiBegin();   // display + boot splash + SD indexing
void uiTick();    // call every loop(); non-blocking apart from a single IR frame (<0.5 s)
