#pragma once
#include "IrFile.h"
namespace IrTx {
void begin();
// raw = timing buffer that belongs to `s` (used when s.isRaw). Blocking: ~0.1-0.4 s.
bool send(const IrSignal& s, const uint32_t* raw);
}
