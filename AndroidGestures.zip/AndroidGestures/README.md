# Android Gestures

Жест «Назад» в стиле Android для iOS 15–16 (jailbreak): свайп от левого/правого края, чёрная выпуклая область с белой стрелкой, тактильный отклик, панель настроек.

## Установка
Скачайте `.deb` из Releases: `AndroidGestures-rootful.deb` (palera1n rootful, unc0ver, checkra1n) или `AndroidGestures-rootless.deb` (Dopamine, palera1n rootless). **Важно:** на Dopamine и palera1n rootless ставьте только `rootless`-вариант, иначе будет ошибка «Depends ...:iphoneos-arm». Установите через Sileo/Zebra или `dpkg -i`, затем Respring.
Зависимости: preferenceloader (altlist больше не нужен — список исключений встроен).

## Как работает
- SpringBoard держит прозрачное окно, которое перехватывает касания только в узких полосах у краёв (ширина настраивается).
- Жест при перетягивании рисуется через CAShapeLayer; при пороге отправляется Darwin-уведомление, и приложение на переднем плане выполняет «назад»: pop UINavigationController → WKWebView.goBack → закрытие модального экрана.

## Ограничения
- Приложения без UINavigationController/WebView/модальных экранов (кастомная навигация) не реагируют.
- Нативный свайп-назад iOS в полосе края заменён этим жестом; обычные тапы в самой полосе не доходят до приложения.
- Вертикальный свайп, начатый в полосе, не передаётся приложению.
- Ландшафт не доработан.

## Сборка
`export THEOS=...; make package` (rootful) или `THEOS_PACKAGE_SCHEME=rootless make package`. GitHub Actions собирает оба варианта; тег `v*` публикует релиз.
