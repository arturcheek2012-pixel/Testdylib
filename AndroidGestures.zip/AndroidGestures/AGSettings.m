#import "AGSettings.h"
NSString *const AGSettingsDidChangeNotification = @"AGSettingsDidChange";
static NSString *const kDomain = @"com.androidgestures";

static void AGPrefsChanged(CFNotificationCenterRef c, void *o, CFStringRef n, const void *obj, CFDictionaryRef u) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[AGSettings shared] reload];
        [[NSNotificationCenter defaultCenter] postNotificationName:AGSettingsDidChangeNotification object:nil];
    });
}

@implementation AGSettings { NSUserDefaults *_d; }
+ (instancetype)shared {
    static AGSettings *s; static dispatch_once_t t;
    dispatch_once(&t, ^{
        s = [AGSettings new];
        [s reload];
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, AGPrefsChanged,
            CFSTR("com.androidgestures/prefsChanged"), NULL, CFNotificationSuspensionBehaviorCoalesce);
    });
    return s;
}
- (void)reload {
    NSUserDefaults *d = [[NSUserDefaults alloc] initWithSuiteName:kDomain];
    [d registerDefaults:@{
        @"enabled": @YES, @"left": @YES, @"right": @YES, @"haptics": @YES, @"hapticOnSuccess": @YES,
        @"hapticIntensity": @0.8, @"animStyle": @0, @"animSpeed": @1.0, @"sensitivity": @1.0,
        @"activationDistance": @90, @"arrowVisible": @YES, @"edgeWidth": @20, @"threshold": @0.85, @"cancelMode": @0 }];
    _d = d;
    _enabled = [d boolForKey:@"enabled"]; _left = [d boolForKey:@"left"]; _right = [d boolForKey:@"right"];
    _haptics = [d boolForKey:@"haptics"]; _hapticOnSuccess = [d boolForKey:@"hapticOnSuccess"];
    _arrowVisible = [d boolForKey:@"arrowVisible"];
    _hapticIntensity = [d floatForKey:@"hapticIntensity"];
    _animSpeed = MAX(0.3, [d floatForKey:@"animSpeed"]);
    _sensitivity = MAX(0.3, [d floatForKey:@"sensitivity"]);
    _activationDistance = MAX(20, [d floatForKey:@"activationDistance"]);
    _edgeWidth = MAX(8, [d floatForKey:@"edgeWidth"]);
    _threshold = MIN(1, MAX(0.2, [d floatForKey:@"threshold"]));
    _animStyle = [d integerForKey:@"animStyle"]; _cancelMode = [d integerForKey:@"cancelMode"];
}
- (BOOL)isExcluded:(NSString *)bid { return bid ? [_d boolForKey:[@"ex-" stringByAppendingString:bid]] : NO; }
@end
