#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
extern NSString *const AGSettingsDidChangeNotification;
@interface AGSettings : NSObject
+ (instancetype)shared;
@property (nonatomic) BOOL enabled, left, right, haptics, hapticOnSuccess, arrowVisible;
@property (nonatomic) CGFloat hapticIntensity, animSpeed, sensitivity, activationDistance, edgeWidth, threshold;
@property (nonatomic) NSInteger animStyle, cancelMode;
- (void)reload;
- (BOOL)isExcluded:(NSString *)bundleID;
@end
