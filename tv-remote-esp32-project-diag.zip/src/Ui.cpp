#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <string.h>
#include <esp_system.h>
#include "config.h"
#include "Ui.h"
#include "Buttons.h"
#include "IrDb.h"
#include "IrTx.h"
#include "Store.h"
#include "Games.h"

namespace {
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
bool oledOk = false, dispOn = true, dirty = true;
uint32_t lastAct = 0;

enum Screen : uint8_t { SCR_MAIN, SCR_BRANDS, SCR_PROFILES, SCR_REMOTE, SCR_FAVS, SCR_SCAN_MENU, SCR_SCAN_BRANDS,
                        SCR_SCAN_RUN, SCR_SCAN_REVIEW, SCR_SD, SCR_SETTINGS, SCR_ABOUT, SCR_CONFIRM, SCR_GAMES, SCR_GAME_RUN, SCR_BTNTEST };
Screen scr = SCR_MAIN, remoteFrom = SCR_PROFILES, confirmBack = SCR_MAIN;
enum Confirm : uint8_t { CNF_REMOVE_FAV, CNF_RESTART } confirmKind = CNF_RESTART;

struct Lst { int16_t cur = 0, top = 0; };
Lst lGames, lMain, lBrand, lProf, lRemote, lFav, lScanMenu, lSettings, lReview;
uint16_t selBrand = 0, curProf = 0, nCmd = 0;
uint8_t pendingFav = 0;
uint32_t gameLast = 0; bool gOkEdge = false, gUpEdge = false;

char toast[24]; uint32_t toastUntil = 0;
void showToast(const char* t, uint32_t ms = 1200) { strncpy(toast, t, sizeof toast - 1); toast[sizeof toast - 1] = 0; toastUntil = millis() + ms; dirty = true; }

// Option tables
const uint8_t kBriPct[5] = {10, 25, 50, 75, 100};
const uint16_t kTmoSec[5] = {0, 15, 30, 60, 300};
const uint16_t kSpdMs[4] = {600, 1200, 2000, 3000};
const char* const kSpdName[4] = {"Fast 0.6s", "Normal 1.2s", "Slow 2s", "Very slow 3s"};

// Power scan state
uint16_t scanList[kMaxProfiles]; uint16_t scanN = 0, scanPos = 0, lastSent = 0, revIdx = 0;
bool scanPaused = false, scanDone = false, scanSentAny = false; uint32_t scanNextAt = 0;

// ---------------- button diagnostics (Settings -> Button test) ----------------
// Counts every falling edge on each button pin from an interrupt, so even very short
// electrical glitches (which the debounce hides) become visible.
volatile uint32_t edgeCnt[4];
void IRAM_ATTR isrU() { edgeCnt[0]++; }
void IRAM_ATTR isrD() { edgeCnt[1]++; }
void IRAM_ATTR isrO() { edgeCnt[2]++; }
void IRAM_ATTR isrB() { edgeCnt[3]++; }
uint8_t evLog[4] = {0, 0, 0, 0};
void evPush(Btn b) {
  uint8_t c = b == Btn::Up ? 1 : b == Btn::Down ? 2 : b == Btn::Ok ? 3 : b == Btn::Back ? 4 : b == Btn::OkLong ? 5 : 0;
  for (int i = 3; i > 0; i--) evLog[i] = evLog[i - 1];
  evLog[0] = c;
}
const char* resetName() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON: return "POWER ON";
    case ESP_RST_SW: return "SOFTWARE";
    case ESP_RST_PANIC: return "CRASH (panic)";
    case ESP_RST_INT_WDT: case ESP_RST_TASK_WDT: case ESP_RST_WDT: return "WATCHDOG";
    case ESP_RST_BROWNOUT: return "BROWNOUT (power)";
    case ESP_RST_EXT: return "EXT RESET";
    default: return "OTHER";
  }
}
void diagStart() {
  const uint8_t pins[4] = {PIN_BTN_UP, PIN_BTN_DOWN, PIN_BTN_OK, PIN_BTN_BACK};
  void (*const fns[4])() = {isrU, isrD, isrO, isrB};
  for (int i = 0; i < 4; i++) {
    edgeCnt[i] = 0; evLog[i] = 0;
    attachInterrupt(digitalPinToInterrupt(pins[i]), fns[i], BTN_ACTIVE_LOW ? FALLING : RISING);
  }
}
void diagStop() {
  const uint8_t pins[4] = {PIN_BTN_UP, PIN_BTN_DOWN, PIN_BTN_OK, PIN_BTN_BACK};
  for (int i = 0; i < 4; i++) detachInterrupt(digitalPinToInterrupt(pins[i]));
}

// ---------------- display helpers ----------------
void applyContrast() {
  if (!oledOk) return;
  uint8_t v = (uint8_t)((uint32_t)kBriPct[Store::set.bri] * 255 / 100);
  oled.ssd1306_command(SSD1306_SETCONTRAST); oled.ssd1306_command(v);
}
void dispSleep(bool off) {
  if (!oledOk || dispOn == !off) return;
  oled.ssd1306_command(off ? SSD1306_DISPLAYOFF : SSD1306_DISPLAYON); dispOn = !off;
}
bool probe(uint8_t a) { Wire.beginTransmission(a); return Wire.endTransmission() == 0; }

void txt(int x, int y, const char* s) { oled.setCursor(x, y); oled.print(s); }
void header(const char* t, const char* right = nullptr) {
  oled.setTextColor(WHITE); txt(0, 1, t);
  if (right) txt(128 - 6 * (int)strlen(right), 1, right);
  oled.drawFastHLine(0, 10, 128, WHITE);
}
void bar(int x, int y, int w, int h, uint32_t num, uint32_t den) {
  oled.drawRect(x, y, w, h, WHITE);
  if (den) { int f = (int)((uint64_t)(w - 2) * num / den); if (f > 0) oled.fillRect(x + 1, y + 1, f, h - 2, WHITE); }
}
typedef void (*LabelFn)(int idx, char* out, size_t n);
void drawList(int y0, int vis, int n, const Lst& l, LabelFn fn) {
  char b[40];
  for (int r = 0; r < vis; r++) {
    int i = l.top + r; if (i >= n) break;
    fn(i, b, sizeof b);
    int y = y0 + r * 10; bool sel = (i == l.cur);
    if (sel) oled.fillRect(0, y - 1, 128, 10, WHITE);
    oled.setTextColor(sel ? BLACK : WHITE); txt(2, y, b);
  }
  oled.setTextColor(WHITE);
}
void lfix(Lst& l, int n, int vis) {
  if (n <= 0) { l.cur = l.top = 0; return; }
  if (l.cur >= n) l.cur = n - 1;
  if (l.cur < l.top) l.top = l.cur;
  if (l.cur >= l.top + vis) l.top = l.cur - vis + 1;
}
bool lnav(Lst& l, int n, Btn b, int vis) {
  if (n <= 0) return false;
  if (b == Btn::Up) l.cur = l.cur ? l.cur - 1 : n - 1;
  else if (b == Btn::Down) l.cur = (l.cur + 1 < n) ? l.cur + 1 : 0;
  else return false;
  lfix(l, n, vis); return true;
}
void counter(char* out, size_t n, const Lst& l, int total) { snprintf(out, n, "%d/%d", total ? l.cur + 1 : 0, total); }

void drawBoot(uint16_t done, uint16_t total) {
  if (!oledOk) return;
  oled.clearDisplay(); oled.setTextColor(WHITE);
  oled.setTextSize(2); txt(10, 10, "TV REMOTE"); oled.setTextSize(1);
  txt(10, 32, "IR Remote Controller");
  txt(22, 44, done >= total ? "Ready" : "Reading SD...");
  bar(14, 54, 100, 7, done, total ? total : 1);
  oled.display();
}
void bootProgress(uint16_t d, uint16_t t) { static uint32_t last = 0; if (millis() - last > 120 || d >= t) { last = millis(); drawBoot(d, t); } }

// ---------------- labels ----------------
const char* const kMainItems[7] = {"1 TV Remotes", "2 Favorites", "3 Power Scan", "4 SD Card", "5 Games", "6 Settings", "7 About"};
void lblMain(int i, char* o, size_t n) { snprintf(o, n, "%s", kMainItems[i]); }
void lblBrand(int i, char* o, size_t n) { snprintf(o, n, "%s (%u)", IrDb::brandName(i), IrDb::brandSize(i)); }
void lblProf(int i, char* o, size_t n) { snprintf(o, n, "%s", IrDb::profileName(IrDb::brandFirst(selBrand) + i)); }
void lblCmd(int i, char* o, size_t n) {
  if (i < nCmd) snprintf(o, n, "%s", IrDb::cmdLabel(i));
  else snprintf(o, n, "%s", Store::favFind(IrDb::profilePath(curProf), IrDb::profileStart(curProf)) >= 0 ? "[-] Remove favorite" : "[+] Add to favorites");
}
void lblGames(int i, char* o, size_t n) { snprintf(o, n, "%s", Games::name(i)); }
void lblFav(int i, char* o, size_t n) { snprintf(o, n, "%s", Store::fav(i).title); }
void lblScanMenu(int i, char* o, size_t n) { snprintf(o, n, "%s", i == 0 ? "Scan all brands" : "Scan one brand..."); }
void lblReview(int i, char* o, size_t n) {
  static const char* const t[6] = {"Resend power", "Open remote", "Add favorite", "Previous candidate", "Next candidate", "Resume scan"};
  snprintf(o, n, "%s", t[i]);
}
void lblSettings(int i, char* o, size_t n) {
  const Store::Settings& s = Store::set;
  switch (i) {
    case 0: snprintf(o, n, "Brightness: %u%%", kBriPct[s.bri]); break;
    case 1: if (kTmoSec[s.tmo]) snprintf(o, n, "Screen off: %us", kTmoSec[s.tmo]); else snprintf(o, n, "Screen off: never"); break;
    case 2: snprintf(o, n, "Scan: %s", kSpdName[s.spd]); break;
    case 3: snprintf(o, n, "Button test"); break;
    default: snprintf(o, n, "Restart device"); break;
  }
}

// ---------------- scan ----------------
void buildScanList(int brand) {  // brand < 0 = all
  scanN = 0;
  uint16_t a = 0, b = IrDb::stats().profiles;
  if (brand >= 0) { a = IrDb::brandFirst(brand); b = a + IrDb::brandSize(brand); }
  for (uint16_t p = a; p < b; p++) if (IrDb::profileScannable(p) && scanN < kMaxProfiles) scanList[scanN++] = p;
}
uint16_t scanCountAll() { uint16_t c = 0, n = IrDb::stats().profiles; for (uint16_t p = 0; p < n; p++) if (IrDb::profileScannable(p)) c++; return c; }
void startScan(int brand) {
  buildScanList(brand);
  if (!scanN) { showToast("No power codes"); return; }
  scanPos = 0; lastSent = 0; scanPaused = false; scanDone = false; scanSentAny = false; scanNextAt = millis();
  scr = SCR_SCAN_RUN; dirty = true;
}
void scanStep() {
  if (scr != SCR_SCAN_RUN || scanPaused || scanDone) return;
  uint32_t now = millis(); lastAct = now;
  if ((int32_t)(now - scanNextAt) < 0) return;
  if (scanPos >= scanN) { scanDone = true; dirty = true; return; }
  if (!IrDb::sendPower(scanList[scanPos])) showToast("Send failed", 600);
  lastSent = scanPos; scanSentAny = true; scanPos++;
  scanNextAt = millis() + kSpdMs[Store::set.spd]; dirty = true;
}

// ---------------- actions ----------------
void openRemote(uint16_t p, Screen from) {
  nCmd = IrDb::loadCommands(p);
  if (!nCmd) { showToast("No commands / SD error"); return; }
  curProf = p; remoteFrom = from; lRemote = Lst(); scr = SCR_REMOTE; dirty = true;
}
void titleFor(uint16_t p, char* out, size_t n) { snprintf(out, n, "%s/%s", IrDb::profileBrand(p), IrDb::profileName(p)); }
void addFavFor(uint16_t p) {
  char t[24]; titleFor(p, t, sizeof t);
  switch (Store::favAdd(IrDb::profilePath(p), IrDb::profileStart(p), t)) {
    case Store::FAV_OK: showToast("Added to favorites"); break;
    case Store::FAV_EXISTS: showToast("Already in favorites"); break;
    case Store::FAV_FULL: showToast("Favorites full (16)"); break;
    default: showToast("Save failed"); break;
  }
}
bool needDb() {
  if (IrDb::stats().ready && IrDb::stats().profiles) return true;
  showToast(IrDb::stats().initOk ? "DB not found on SD" : "SD card not available", 1800); return false;
}
void doRescan() {
  if (!IrDb::mount()) { drawBoot(1, 1); }
  IrDb::build(bootProgress);
  lBrand = lProf = lRemote = Lst(); lScanMenu = Lst();
  showToast(IrDb::stats().ready ? "SD re-read OK" : "SD/DB problem", 1500);
}

// ---------------- rendering ----------------
void render() {
  if (!oledOk || !dispOn) { dirty = false; return; }
  oled.clearDisplay(); oled.setTextColor(WHITE); oled.setTextSize(1); oled.setTextWrap(false);
  char b[40], c[16]; const IrDb::Stats& st = IrDb::stats();
  switch (scr) {
    case SCR_MAIN: drawList(2, 6, 7, lMain, lblMain); break;
    case SCR_GAMES: header("Games"); drawList(12, 5, Games::GAME_COUNT, lGames, lblGames); break;
    case SCR_GAME_RUN: Games::draw(oled); break;
    case SCR_BRANDS: case SCR_SCAN_BRANDS:
      counter(c, sizeof c, lBrand, IrDb::brandCount());
      header(scr == SCR_BRANDS ? "TV Remotes" : "Scan: brand", c); drawList(12, 5, IrDb::brandCount(), lBrand, lblBrand); break;
    case SCR_PROFILES:
      counter(c, sizeof c, lProf, IrDb::brandSize(selBrand));
      snprintf(b, sizeof b, "%.12s", IrDb::brandName(selBrand)); header(b, c);
      drawList(12, 5, IrDb::brandSize(selBrand), lProf, lblProf); break;
    case SCR_REMOTE: {
      bool f = Store::favFind(IrDb::profilePath(curProf), IrDb::profileStart(curProf)) >= 0;
      snprintf(b, sizeof b, "%s%.19s", f ? "*" : "", IrDb::profileName(curProf)); header(b);
      drawList(12, 5, nCmd + 1, lRemote, lblCmd); break; }
    case SCR_FAVS:
      counter(c, sizeof c, lFav, Store::favCount()); header("Favorites", c);
      if (!Store::favCount()) { txt(4, 22, "Empty."); txt(4, 34, "Add from a remote or"); txt(4, 44, "after Power Scan."); }
      else drawList(12, 5, Store::favCount(), lFav, lblFav);
      break;
    case SCR_SCAN_MENU:
      header("Power Scan"); snprintf(b, sizeof b, "%u unique power codes", scanCountAll()); txt(2, 13, b);
      drawList(25, 2, 2, lScanMenu, lblScanMenu); txt(2, 48, "Sends POWER codes one"); txt(2, 56, "by one. You confirm."); break;
    case SCR_SCAN_RUN: {
      header(scanPaused ? "Power Scan PAUSED" : (scanDone ? "Scan complete" : "Power Scan"));
      if (scanSentAny) {
        snprintf(b, sizeof b, "%.21s", IrDb::profileBrand(scanList[lastSent])); txt(0, 13, b);
        snprintf(b, sizeof b, "%.21s", IrDb::profileName(scanList[lastSent])); txt(0, 23, b);
        snprintf(b, sizeof b, "%u/%u  %s", lastSent + 1, scanN, IrDb::profilePowerProto(scanList[lastSent])); txt(0, 33, b);
      } else txt(0, 23, "Starting...");
      bar(0, 44, 128, 8, scanDone ? scanN : scanPos, scanN);
      txt(0, 55, scanDone ? "OK:review BACK:exit" : (scanPaused ? "UP:go OK:found BACK:stop" : "UP:pause OK:TV reacted")); break; }
    case SCR_SCAN_REVIEW: {
      uint16_t p = scanList[revIdx];
      snprintf(b, sizeof b, "Found? %u/%u", revIdx + 1, scanN); header(b);
      snprintf(b, sizeof b, "%.21s", IrDb::profileBrand(p)); txt(0, 12, b);
      snprintf(b, sizeof b, "%.21s", IrDb::profileName(p)); txt(0, 21, b);
      drawList(34, 3, 6, lReview, lblReview); break; }
    case SCR_SD: {
      header("SD Card");
      snprintf(b, sizeof b, "Card: %s", st.cardFound ? "found" : "NOT FOUND"); txt(0, 12, b);
      if (st.cardFound) { snprintf(b, sizeof b, "Init: OK  %lu MB", (unsigned long)(st.cardBytes / 1048576ULL)); } else snprintf(b, sizeof b, "Init: FAILED");
      txt(0, 21, b);
      snprintf(b, sizeof b, "TV profiles: %u (%u br)", st.profiles, st.brands); txt(0, 30, b);
      snprintf(b, sizeof b, "IR cmds: %lu (-%lu)", (unsigned long)st.sendable, (unsigned long)st.unsupported); txt(0, 39, b);
      snprintf(b, sizeof b, "Read: %s%s", st.ready ? (st.readErrors ? "ERR " : "OK ") : "no DB ", st.truncated ? "TRUNC" : ""); txt(0, 48, b);
      txt(0, 56, "OK: re-read card"); break; }
    case SCR_BTNTEST: {
      static const char* const en[6] = {"--", "UP", "DN", "OK", "BK", "OKL"};
      snprintf(b, sizeof b, "Level U%d D%d O%d B%d", digitalRead(PIN_BTN_UP), digitalRead(PIN_BTN_DOWN), digitalRead(PIN_BTN_OK), digitalRead(PIN_BTN_BACK)); txt(0, 0, b);
      snprintf(b, sizeof b, "Edges U%lu D%lu", (unsigned long)edgeCnt[0], (unsigned long)edgeCnt[1]); txt(0, 10, b);
      snprintf(b, sizeof b, "Edges O%lu B%lu", (unsigned long)edgeCnt[2], (unsigned long)edgeCnt[3]); txt(0, 20, b);
      snprintf(b, sizeof b, "Ev: %s %s %s %s", en[evLog[0]], en[evLog[1]], en[evLog[2]], en[evLog[3]]); txt(0, 30, b);
      snprintf(b, sizeof b, "rst:%s", resetName()); txt(0, 40, b);
      txt(0, 54, "hold OK 1s = exit"); break; }
    case SCR_SETTINGS: header("Settings"); drawList(12, 5, 5, lSettings, lblSettings); break;
    case SCR_ABOUT:
      txt(0, 0, "TV REMOTE"); txt(0, 10, "Firmware " FW_VERSION); txt(0, 20, "ESP32");
      txt(0, 30, "OLED: 128x64"); txt(0, 40, "IR Remote Controller");
      snprintf(b, sizeof b, "SD DB: %s %u prof", st.ready ? "OK" : "none", st.profiles); txt(0, 52, b); break;
    case SCR_CONFIRM:
      header("Confirm");
      if (confirmKind == CNF_RESTART) txt(2, 22, "Restart the device?");
      else { txt(2, 22, "Remove favorite?"); snprintf(b, sizeof b, "%.21s", Store::fav(pendingFav).title); txt(2, 32, b); }
      txt(2, 50, "OK:yes  BACK:no"); break;
  }
  if (toastUntil && (int32_t)(millis() - toastUntil) < 0) {
    oled.fillRect(0, 54, 128, 10, WHITE); oled.setTextColor(BLACK); txt(2, 55, toast); oled.setTextColor(WHITE);
  }
  oled.display(); dirty = false;
}

// ---------------- input ----------------
void onButton(Btn b) {
  switch (scr) {
    case SCR_MAIN:
      if (lnav(lMain, 7, b, 6)) break;
      if (b == Btn::Ok) switch (lMain.cur) {
        case 0: if (needDb()) { lfix(lBrand, IrDb::brandCount(), 5); scr = SCR_BRANDS; } break;
        case 1: lfix(lFav, Store::favCount(), 5); scr = SCR_FAVS; break;
        case 2: if (needDb()) scr = SCR_SCAN_MENU; break;
        case 3: scr = SCR_SD; break;
        case 4: scr = SCR_GAMES; break;
        case 5: scr = SCR_SETTINGS; break;
        default: scr = SCR_ABOUT; break;
      }
      break;
    case SCR_BRANDS:
      if (lnav(lBrand, IrDb::brandCount(), b, 5)) break;
      if (b == Btn::Back) scr = SCR_MAIN;
      else if (b == Btn::Ok && IrDb::brandCount()) { selBrand = lBrand.cur; lProf = Lst(); scr = SCR_PROFILES; }
      break;
    case SCR_PROFILES:
      if (lnav(lProf, IrDb::brandSize(selBrand), b, 5)) break;
      if (b == Btn::Back) scr = SCR_BRANDS;
      else if (b == Btn::Ok) openRemote(IrDb::brandFirst(selBrand) + lProf.cur, SCR_PROFILES);
      break;
    case SCR_REMOTE:
      if (lnav(lRemote, nCmd + 1, b, 5)) break;
      if (b == Btn::Back) scr = remoteFrom;
      else if (b == Btn::Ok) {
        if (lRemote.cur < nCmd) {
          bool ok = IrDb::sendCmd(curProf, lRemote.cur);
          char t[24]; snprintf(t, sizeof t, ok ? "Sent: %.14s" : "Send failed: %.9s", IrDb::cmdLabel(lRemote.cur)); showToast(t, 600);
        } else {
          int i = Store::favFind(IrDb::profilePath(curProf), IrDb::profileStart(curProf));
          if (i >= 0) showToast(Store::favRemove(i) ? "Removed" : "Save failed"); else addFavFor(curProf);
        }
      }
      break;
    case SCR_FAVS:
      if (lnav(lFav, Store::favCount(), b, 5)) break;
      if (b == Btn::Back) scr = SCR_MAIN;
      else if (b == Btn::Ok && Store::favCount()) {
        const Store::Fav& f = Store::fav(lFav.cur); int p = IrDb::findProfile(f.path, f.start);
        if (p < 0) showToast("Not in DB (OK long=del)", 1500); else openRemote(p, SCR_FAVS);
      } else if (b == Btn::OkLong && Store::favCount()) { pendingFav = lFav.cur; confirmKind = CNF_REMOVE_FAV; confirmBack = SCR_FAVS; scr = SCR_CONFIRM; }
      break;
    case SCR_SCAN_MENU:
      if (lnav(lScanMenu, 2, b, 2)) break;
      if (b == Btn::Back) scr = SCR_MAIN;
      else if (b == Btn::Ok) { if (lScanMenu.cur == 0) startScan(-1); else { lfix(lBrand, IrDb::brandCount(), 5); scr = SCR_SCAN_BRANDS; } }
      break;
    case SCR_SCAN_BRANDS:
      if (lnav(lBrand, IrDb::brandCount(), b, 5)) break;
      if (b == Btn::Back) scr = SCR_SCAN_MENU;
      else if (b == Btn::Ok && IrDb::brandCount()) startScan(lBrand.cur);
      break;
    case SCR_SCAN_RUN:
      if (b == Btn::Back) { scr = SCR_SCAN_MENU; }
      else if (b == Btn::Up || b == Btn::Down) { if (!scanDone) { scanPaused = !scanPaused; if (!scanPaused) scanNextAt = millis(); } }
      else if (b == Btn::Ok && scanSentAny) { scanPaused = true; revIdx = scanDone ? scanN - 1 : lastSent; lReview = Lst(); scr = SCR_SCAN_REVIEW; }
      break;
    case SCR_SCAN_REVIEW:
      if (lnav(lReview, 6, b, 3)) break;
      if (b == Btn::Back) scr = SCR_SCAN_RUN;
      else if (b == Btn::Ok) switch (lReview.cur) {
        case 0: showToast(IrDb::sendPower(scanList[revIdx]) ? "Power sent" : "Send failed", 700); break;
        case 1: openRemote(scanList[revIdx], SCR_SCAN_REVIEW); break;
        case 2: addFavFor(scanList[revIdx]); break;
        case 3: if (revIdx > 0) revIdx--; break;
        case 4: if (revIdx + 1 < scanN && revIdx < lastSent) revIdx++; break;
        default: if (!scanDone) { scanPaused = false; scanNextAt = millis() + 300; } scr = SCR_SCAN_RUN; break;
      }
      break;
    case SCR_SD:
      if (b == Btn::Back) scr = SCR_MAIN; else if (b == Btn::Ok) doRescan();
      break;
    case SCR_SETTINGS:
      if (lnav(lSettings, 5, b, 5)) break;
      if (b == Btn::Back) scr = SCR_MAIN;
      else if (b == Btn::Ok) switch (lSettings.cur) {
        case 0: Store::set.bri = (Store::set.bri + 1) % 5; applyContrast(); if (!Store::saveSettings()) showToast("Save failed"); break;
        case 1: Store::set.tmo = (Store::set.tmo + 1) % 5; if (!Store::saveSettings()) showToast("Save failed"); break;
        case 2: Store::set.spd = (Store::set.spd + 1) % 4; if (!Store::saveSettings()) showToast("Save failed"); break;
        case 3: diagStart(); scr = SCR_BTNTEST; break;
        case 4: confirmKind = CNF_RESTART; confirmBack = SCR_SETTINGS; scr = SCR_CONFIRM; break;
        default: break;
      }
      break;
    case SCR_ABOUT: if (b == Btn::Back) scr = SCR_MAIN; break;
    case SCR_GAMES:
      if (lnav(lGames, Games::GAME_COUNT, b, 5)) break;
      if (b == Btn::Back) scr = SCR_MAIN;
      else if (b == Btn::Ok) { Games::start(lGames.cur); gameLast = 0; gOkEdge = gUpEdge = false; scr = SCR_GAME_RUN; }
      break;
    case SCR_GAME_RUN:
      if (b == Btn::Back) scr = SCR_GAMES;
      else if (b == Btn::Ok) gOkEdge = true;
      else if (b == Btn::Up) gUpEdge = true;
      break;
    case SCR_BTNTEST:
      evPush(b);
      if (b == Btn::OkLong) { diagStop(); scr = SCR_SETTINGS; }
      break;
    case SCR_CONFIRM:
      if (b == Btn::Back) scr = confirmBack;
      else if (b == Btn::Ok) {
        if (confirmKind == CNF_RESTART) { ESP.restart(); }
        else { showToast(Store::favRemove(pendingFav) ? "Removed" : "Save failed"); lfix(lFav, Store::favCount(), 5); scr = confirmBack; }
      }
      break;
  }
  dirty = true;
}
}  // namespace

void uiBegin() {
  buttonsBegin(); Store::begin();
  Wire.begin(PIN_OLED_SDA, PIN_OLED_SCL); Wire.setClock(400000);
  uint8_t addr = OLED_I2C_ADDR ? OLED_I2C_ADDR : (probe(0x3C) ? 0x3C : (probe(0x3D) ? 0x3D : 0));
  if (addr && oled.begin(SSD1306_SWITCHCAPVCC, addr)) {
    oledOk = true; oled.setRotation(OLED_ROT); oled.setTextWrap(false); applyContrast();
  } else Serial.println("OLED not found (check SDA/SCL/address in config.h)");
  uint32_t t0 = millis(); drawBoot(0, 1);
  IrTx::begin();
  IrDb::mount();
  IrDb::build(bootProgress);
  while (millis() - t0 < 1500) delay(10);
  Serial.printf("SD:%d ready:%d brands:%u profiles:%u sendable:%lu\n", IrDb::stats().initOk, IrDb::stats().ready,
                IrDb::stats().brands, IrDb::stats().profiles, (unsigned long)IrDb::stats().sendable);
  lastAct = millis(); dirty = true;
  // Hold OK while powering on / pressing EN -> go straight to the button test (no menus needed)
  if (digitalRead(PIN_BTN_OK) == (BTN_ACTIVE_LOW ? LOW : HIGH)) { diagStart(); scr = SCR_BTNTEST; }
}

void uiTick() {
  Btn b = buttonsPoll();
  uint32_t now = millis();
  if (b != Btn::None) {
    lastAct = now;
    if (!dispOn) { dispSleep(false); dirty = true; }      // first press only wakes the screen
    else onButton(b);
  }
  scanStep();
  if (scr == SCR_BTNTEST) { lastAct = now; static uint32_t dl = 0; if (now - dl >= 60) { dl = now; dirty = true; } }
  if (scr == SCR_GAME_RUN) {
    lastAct = now;
    if (now - gameLast >= 40) {
      gameLast = now;
      Games::Input in = {buttonHeld(Btn::Up), buttonHeld(Btn::Down), buttonHeld(Btn::Ok), gOkEdge, gUpEdge};
      gOkEdge = gUpEdge = false; Games::update(now, in); dirty = true;
    }
  }
  uint32_t tmo = (uint32_t)kTmoSec[Store::set.tmo] * 1000UL;
  if (tmo && dispOn && now - lastAct > tmo) dispSleep(true);
  if (toastUntil && (int32_t)(now - toastUntil) >= 0) { toastUntil = 0; dirty = true; }
  if (dirty) render();
}
