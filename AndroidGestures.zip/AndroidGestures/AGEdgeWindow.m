#import <objc/message.h>
#import "AGEdgeWindow.h"
#import "AGBackView.h"
#import "AGHaptics.h"
#import "AGSettings.h"
#import "AGBackAction.h"

@interface SBApplication : NSObject
- (NSString *)bundleIdentifier;
@end
@interface SpringBoard : UIApplication
- (SBApplication *)_accessibilityFrontMostApplication;
- (UIInterfaceOrientation)activeInterfaceOrientation;
@end

static const CGFloat kExpandedWidth = 96; // room for the biggest bubble

static CGRect AGStripFrame(BOOL right, BOOL expanded) {
    CGRect sb = UIScreen.mainScreen.bounds;
    CGFloat w = expanded ? kExpandedWidth : [AGSettings shared].edgeWidth;
    return CGRectMake(right ? sb.size.width - w : 0, 0, w, sb.size.height);
}

static BOOL AGScreenLocked(void) {
    Class c = NSClassFromString(@"SBLockScreenManager");
    id m = [c respondsToSelector:@selector(sharedInstance)] ? [c performSelector:@selector(sharedInstance)] : nil;
    if (m && [m respondsToSelector:@selector(isUILocked)])
        return ((BOOL (*)(id, SEL))objc_msgSend)(m, @selector(isUILocked));
    return NO;
}

// YES only while a (non-excluded) app is in the foreground in portrait.
static BOOL AGFrontAppAllowed(void) {
    UIApplication *app = UIApplication.sharedApplication;
    if (!app || AGScreenLocked()) return NO;
    if ([app respondsToSelector:@selector(activeInterfaceOrientation)] &&
        UIInterfaceOrientationIsLandscape([(SpringBoard *)app activeInterfaceOrientation])) return NO;
    if (![app respondsToSelector:@selector(_accessibilityFrontMostApplication)]) return YES;
    NSString *bid = [[(SpringBoard *)app _accessibilityFrontMostApplication] bundleIdentifier];
    return bid.length && ![[AGSettings shared] isExcluded:bid];
}

#pragma mark - Touch view

@interface AGTouchView : UIView
- (instancetype)initWithFrame:(CGRect)f right:(BOOL)right;
@end

@implementation AGTouchView {
    AGBackView *_bv;
    BOOL _right, _tracking, _began, _armed, _ignored;
    CGPoint _start; // screen coordinates
}
- (instancetype)initWithFrame:(CGRect)f right:(BOOL)right {
    if (!(self = [super initWithFrame:f])) return nil;
    _right = right;
    self.backgroundColor = UIColor.clearColor;
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _bv = [[AGBackView alloc] initWithFrame:self.bounds right:right];
    [self addSubview:_bv];
    return self;
}
- (AGEdgeWindow *)edgeWindow {
    return [self.window isKindOfClass:AGEdgeWindow.class] ? (AGEdgeWindow *)self.window : nil;
}
- (CGPoint)screenPoint:(UITouch *)t {
    CGPoint l = [t locationInView:nil];          // window coordinates
    CGPoint o = self.window.frame.origin;        // window origin on screen
    return CGPointMake(l.x + o.x, l.y + o.y);
}
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)e {
    AGSettings *s = [AGSettings shared];
    if (!s.enabled) return nil;
    if (_tracking) return self;
    CGFloat W = self.bounds.size.width;
    BOOL inEdge = _right ? (p.x >= W - s.edgeWidth) : (p.x <= s.edgeWidth);
    return inEdge ? self : nil;
}
- (void)touchesBegan:(NSSet<UITouch *> *)t withEvent:(UIEvent *)e {
    if (_tracking) return;
    _tracking = YES; _began = NO; _armed = NO; _ignored = NO;
    _start = [self screenPoint:t.anyObject];
    [self edgeWindow].busy = YES;
}
- (void)touchesMoved:(NSSet<UITouch *> *)t withEvent:(UIEvent *)e {
    if (!_tracking || _ignored) return;
    AGSettings *s = [AGSettings shared];
    CGPoint sp = [self screenPoint:t.anyObject];
    CGFloat dx = _right ? _start.x - sp.x : sp.x - _start.x, dy = sp.y - _start.y;
    if (!_began) {
        if (fabs(dx) + fabs(dy) < 8) return;
        if (dx <= 0 || fabs(dy) > fabs(dx)) { _ignored = YES; return; } // vertical / wrong direction
        _began = YES;
        [[self edgeWindow] expandForBubble];
        [AGHaptics begin];
    }
    CGFloat prog = MIN(1, MAX(0, dx * s.sensitivity / s.activationDistance));
    [_bv setProgress:prog y:[t.anyObject locationInView:self].y];
    if (!_armed && prog >= s.threshold) { _armed = YES; [AGHaptics threshold]; }
    else if (_armed && prog < s.threshold - 0.08) _armed = NO;
}
- (void)finish:(BOOL)commit {
    AGEdgeWindow *w = [self edgeWindow];
    if (_began) {
        if (commit) { [AGHaptics success]; [_bv animateSuccess]; AGPostBack(); }
        else { [AGHaptics cancel]; [_bv animateCancel]; }
        [w collapseAfter:0.5 / [AGSettings shared].animSpeed];
    }
    _tracking = NO; _began = NO; _armed = NO; _ignored = NO;
    w.busy = NO;
}
- (void)touchesEnded:(NSSet<UITouch *> *)t withEvent:(UIEvent *)e { [self finish:_armed]; }
- (void)touchesCancelled:(NSSet<UITouch *> *)t withEvent:(UIEvent *)e { [self finish:NO]; }
@end

#pragma mark - Edge window

@implementation AGEdgeWindow {
    BOOL _expanded; NSUInteger _gen;
}
- (instancetype)initWithRightEdge:(BOOL)right {
    if (!(self = [super initWithFrame:AGStripFrame(right, NO)])) return nil;
    _isRightEdge = right;
    self.windowLevel = UIWindowLevelAlert + 1000;
    self.backgroundColor = UIColor.clearColor;
    UIViewController *vc = [UIViewController new];
    vc.view = [[AGTouchView alloc] initWithFrame:self.bounds right:right];
    self.rootViewController = vc;
    self.hidden = YES; // shown by AGRefresh when an app is in front
    return self;
}
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)e {
    UIView *root = self.rootViewController.view;
    return [root hitTest:[self convertPoint:p toView:root] withEvent:e]; // nil => not ours
}
- (void)applyFrame {
    self.frame = AGStripFrame(_isRightEdge, _expanded);
    self.rootViewController.view.frame = self.bounds;
}
- (void)refreshStrip { if (!_expanded && !self.busy) [self applyFrame]; }
- (void)expandForBubble { _gen++; _expanded = YES; [self applyFrame]; }
- (void)collapseAfter:(NSTimeInterval)delay {
    NSUInteger g = ++_gen;
    __weak AGEdgeWindow *weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        AGEdgeWindow *s = weakSelf;
        if (!s || s->_gen != g || s.busy) return;
        s->_expanded = NO; [s applyFrame];
    });
}
@end

#pragma mark - Start / refresh

static AGEdgeWindow *gLeft, *gRight;
static dispatch_source_t gTimer;

static void AGRefresh(void) {
    AGSettings *s = [AGSettings shared];
    BOOL ok = s.enabled && AGFrontAppAllowed();
    BOOL hideL = !(ok && s.left), hideR = !(ok && s.right);
    if (!gLeft.busy && gLeft.hidden != hideL) gLeft.hidden = hideL;
    if (!gRight.busy && gRight.hidden != hideR) gRight.hidden = hideR;
    [gLeft refreshStrip]; [gRight refreshStrip];
}

void AGEdgeWindowsStart(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gLeft = [[AGEdgeWindow alloc] initWithRightEdge:NO];
        gRight = [[AGEdgeWindow alloc] initWithRightEdge:YES];
        [[NSNotificationCenter defaultCenter] addObserverForName:AGSettingsDidChangeNotification object:nil
                                                           queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) { AGRefresh(); }];
        gTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
        dispatch_source_set_timer(gTimer, DISPATCH_TIME_NOW, 300 * NSEC_PER_MSEC, 50 * NSEC_PER_MSEC);
        dispatch_source_set_event_handler(gTimer, ^{ AGRefresh(); });
        dispatch_resume(gTimer);
        AGRefresh();
    });
}
