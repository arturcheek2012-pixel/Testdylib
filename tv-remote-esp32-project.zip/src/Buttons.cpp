#include "Buttons.h"
#include "config.h"

namespace {
const uint8_t kPins[4] = {PIN_BTN_UP, PIN_BTN_DOWN, PIN_BTN_OK, PIN_BTN_BACK};
const uint32_t kDebounce = 25, kRepeatDelay = 450, kRepeatEvery = 130, kLong = 800;
struct S { bool raw, stable; uint32_t changed, pressedAt, lastRep; bool longDone, ignore; } s[4];
Btn q[6]; uint8_t qh = 0, qn = 0;
void push(Btn b) { if (qn < 6) { q[(qh + qn) % 6] = b; qn++; } }
bool readPin(uint8_t p) { bool v = digitalRead(p); return BTN_ACTIVE_LOW ? !v : v; }
const Btn kMap[4] = {Btn::Up, Btn::Down, Btn::Ok, Btn::Back};
}

void buttonsBegin() {
  for (int i = 0; i < 4; i++) {
    pinMode(kPins[i], BTN_ACTIVE_LOW ? INPUT_PULLUP : INPUT);
    s[i].raw = s[i].stable = readPin(kPins[i]);
    s[i].changed = millis(); s[i].longDone = false;
    s[i].ignore = s[i].stable;           // held at boot: ignore until released
  }
}

Btn buttonsPoll() {
  uint32_t now = millis();
  for (int i = 0; i < 4; i++) {
    bool r = readPin(kPins[i]);
    if (r != s[i].raw) { s[i].raw = r; s[i].changed = now; }
    if (s[i].raw != s[i].stable && now - s[i].changed >= kDebounce) {
      s[i].stable = s[i].raw;
      if (s[i].stable) {                 // pressed
        s[i].pressedAt = now; s[i].lastRep = now; s[i].longDone = false;
        if (!s[i].ignore && i != 2) push(kMap[i]);
      } else {                           // released
        if (!s[i].ignore && i == 2 && !s[i].longDone) push(Btn::Ok);
        s[i].ignore = false;
      }
    }
    if (s[i].stable && !s[i].ignore) {
      if ((i == 0 || i == 1) && now - s[i].pressedAt >= kRepeatDelay && now - s[i].lastRep >= kRepeatEvery) {
        s[i].lastRep = now; push(kMap[i]);
      }
      if (i == 2 && !s[i].longDone && now - s[i].pressedAt >= kLong) { s[i].longDone = true; push(Btn::OkLong); }
    }
  }
  if (!qn) return Btn::None;
  Btn b = q[qh]; qh = (qh + 1) % 6; qn--; return b;
}

bool buttonHeld(Btn b) {
  int i = b == Btn::Up ? 0 : b == Btn::Down ? 1 : b == Btn::Ok ? 2 : b == Btn::Back ? 3 : -1;
  return i >= 0 && s[i].stable && !s[i].ignore;
}
